"""
DataPortal — Veri Yönetim Sistemi
==================================
Flask tabanlı, MySQL bağlantılı kurumsal ETL ve yetki yönetim uygulaması.

Mimari:
    - Her request'te session'dan DB bilgisi okunur, connection pool üzerinden bağlanılır
    - Yetki kontrolü decorator'larla merkezi yapılır
    - Şifreler bcrypt (werkzeug) ile hash'lenerek saklanır
    - Excel yüklemeleri geçici diske yazılır, işlem sonrası silinir
    - CSRF koruması tüm state-değiştiren endpoint'lerde aktiftir
    - Rate limiting brute-force saldırılarına karşı login endpoint'ini korur
    - Audit log tüm kritik işlemleri kaydeder
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, Response
import mysql.connector
from mysql.connector import pooling
import pandas as pd
import os, re, secrets, logging, uuid
from typing import Optional
from datetime import timedelta
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from collections import defaultdict
import time

load_dotenv()

# ─── UYGULAMA KURULUMU ───────────────────────────────────────────────────────

app = Flask(__name__)

app.secret_key = os.environ.get('SECRET_KEY') or os.urandom(32)

# Oturum cookie güvenlik ayarları
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=8)   # 8 saat timeout
app.config['SESSION_COOKIE_HTTPONLY']    = True   # JS erişemez (XSS koruması)
app.config['SESSION_COOKIE_SAMESITE']   = 'Lax'  # CSRF koruması
# Production'da True yapın (HTTPS gerektirir):
app.config['SESSION_COOKIE_SECURE']     = os.environ.get('HTTPS', 'false').lower() == 'true'

app.config['UPLOAD_FOLDER']         = 'uploads'
app.config['MAX_CONTENT_LENGTH']    = 16 * 1024 * 1024   # 16 MB

IZIN_VERILEN_UZANTILAR = {'.xlsx', '.xls'}

KORUNAN_SISTEM_TABLOLARI = {
    'audit_log', 'bildirim', 'cron_gorev', 'dizin', 'dizin_onaylayan',
    'dizin_yetki', 'dosya_yetki', 'excel_dosya', 'excel_onay', 'kalite_kural',
    'kullanici', 'kullanici_tercih', 'rol', 'rol_tablo', 'rol_yetki',
    'tablo_konfig', 'tablo_log', 'yetki', 'yukle_log'
}


# ─── LOGGING ─────────────────────────────────────────────────────────────────
# Yapılandırılmış log: hem konsola hem dosyaya yazar.

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(),                              # Konsol
        logging.FileHandler('dataportal.log', encoding='utf-8')  # Dosya
    ]
)
logger = logging.getLogger('dataportal')

# ─── RATE LIMITER (basit in-memory) ──────────────────────────────────────────
# Harici kütüphane gerektirmeden IP bazlı istek sınırlaması.

_rate_store: dict[str, list[float]] = defaultdict(list)   # {ip: [timestamp,...]}

def rate_limit(max_requests: int, window_seconds: int):
    """
    Belirli bir zaman penceresinde maksimum istek sayısını sınırlar.
    429 Too Many Requests döner ve Retry-After header'ı ekler.

    Args:
        max_requests: Pencere içindeki maksimum istek
        window_seconds: Pencere boyutu (saniye)
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            ip  = request.remote_addr or 'unknown'
            now = time.time()
            # Pencere dışındaki eski zaman damgalarını temizle
            _rate_store[ip] = [t for t in _rate_store[ip] if now - t < window_seconds]
            if len(_rate_store[ip]) >= max_requests:
                retry_after = int(window_seconds - (now - _rate_store[ip][0]))
                logger.warning(f'Rate limit aşıldı: IP={ip}, endpoint={request.endpoint}')
                resp = jsonify({'ok': False, 'msg': f'Çok fazla istek. {retry_after} saniye bekleyin.'})
                resp.headers['Retry-After'] = str(retry_after)
                return resp, 429
            _rate_store[ip].append(now)
            return f(*args, **kwargs)
        return decorated
    return decorator

# ─── CSRF KORUMASI ───────────────────────────────────────────────────────────

def generate_csrf_token():
    """
    Oturuma özgü CSRF token üretir veya mevcutu döner.
    Her oturum açmada yenilenir.
    """
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    return session['csrf_token']

def csrf_protect(f):
    """
    POST/PUT/DELETE isteklerinde X-CSRF-Token header'ını doğrular.
    Token uyuşmazsa 403 döner.
    GET istekleri muaftır.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if request.method in ('POST', 'PUT', 'DELETE', 'PATCH'):
            token = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
            if not token or token != session.get('csrf_token'):
                logger.warning(f'CSRF doğrulaması başarısız: IP={request.remote_addr}, endpoint={request.endpoint}')
                return jsonify({'ok': False, 'msg': 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.'}), 403
        return f(*args, **kwargs)
    return decorated

# ─── ŞİFRE VALİDASYONU ───────────────────────────────────────────────────────

def validate_password(pw: str) -> Optional[str]:
    """
    Şifre kompleksite kurallarını kontrol eder.
    Kural ihlali varsa Türkçe hata mesajı döner, geçerliyse None.

    Kurallar:
        - En az 8 karakter
        - En az 1 büyük harf
        - En az 1 küçük harf
        - En az 1 rakam
    """
    if not pw or len(pw) < 8:
        return 'Şifre en az 8 karakter olmalıdır.'
    if not re.search(r'[A-Z]', pw):
        return 'Şifre en az 1 büyük harf içermelidir.'
    if not re.search(r'[a-z]', pw):
        return 'Şifre en az 1 küçük harf içermelidir.'
    if not re.search(r'\d', pw):
        return 'Şifre en az 1 rakam içermelidir.'
    return None

def validate_email(email: str) -> bool:
    """Basit e-posta format doğrulaması (RFC 5322 basitleştirilmiş)."""
    if not email:
        return True   # E-posta opsiyonel; boş geçilebilir
    return bool(re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email))

# ─── VERİTABANI BAĞLANTI HAVUZU ──────────────────────────────────────────────

_pool = None

def get_pool():
    """
    Mevcut oturumdaki DB konfigürasyonu ile bir MySQLConnectionPool döner.
    Pool ilk çağrıda oluşturulur; sonraki çağrılarda aynı nesne kullanılır.
    """
    global _pool
    cfg = session.get('db')
    if not cfg:
        return None
    if _pool is None:
        try:
            _pool = pooling.MySQLConnectionPool(
                pool_name='dataportal',
                pool_size=5,
                host=cfg['host'],
                port=int(cfg['port']),
                user=cfg['user'],
                password=cfg['password'],
                database=cfg['database'],
                charset='utf8mb4',
                collation='utf8mb4_unicode_ci'
            )
        except Exception as e:
            logger.error(f'Connection pool oluşturulamadı: {e}')
            return None
    return _pool

def get_conn():
    """Pool'dan bir bağlantı alır. Başarısızsa None döner."""
    pool = get_pool()
    if not pool:
        return None
    try:
        return pool.get_connection()
    except Exception as e:
        logger.error(f'Bağlantı alınamadı: {e}')
        return None

def query(sql, params=(), fetchone=False):
    """
    SELECT sorguları için kısa yol.
    Bağlantıyı açar, sorguyu çalıştırır, sonucu döner ve bağlantıyı kapatır.
    """
    conn = get_conn()
    if not conn:
        raise RuntimeError('Veritabanı bağlantısı kurulamadı.')
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params)
        return cur.fetchone() if fetchone else cur.fetchall()
    finally:
        conn.close()

def execute(sql, params=()):
    """
    INSERT / UPDATE / DELETE işlemleri için kısa yol.
    Otomatik commit yapar ve lastrowid döner.
    """
    conn = get_conn()
    if not conn:
        raise RuntimeError('Veritabanı bağlantısı kurulamadı.')
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        lid = cur.lastrowid
        conn.commit()
        return lid
    finally:
        conn.close()

def sanitize(name):
    """Tablo/sütun adını MySQL için güvenli hale getirir."""
    name = re.sub(r'[^\w]', '_', str(name).strip(), flags=re.UNICODE)
    name = re.sub(r'_+', '_', name).strip('_') or 'column'
    return ('col_' + name) if name[0].isdigit() else name

def guvenli_dosya_adi(filename):
    """Dosya adını güvenli hale getirir ve uzantı whitelist kontrolü yapar."""
    filename = secure_filename(filename)
    ext = os.path.splitext(filename)[1].lower()
    if ext not in IZIN_VERILEN_UZANTILAR:
        return None
    # Çakışma önlemek için UUID öneki ekle
    return f"{uuid.uuid4().hex[:8]}_{filename}"

# ─── YETKİ KONTROL ───────────────────────────────────────────────────────────

def kullanici_yetkileri(kullanici_id):
    """Kullanıcının tüm yetkilerini DB'den çeker (yalnızca login sırasında çağrılır)."""
    rows = query("""
        SELECT y.YetkiID FROM kullanici k
        JOIN rol_yetki ry ON k.RolID = ry.RolID
        JOIN yetki y ON ry.YetkiID = y.YetkiID
        WHERE k.KullaniciID = %s
    """, (kullanici_id,))
    return {r['YetkiID'] for r in rows}

def has_yetki(yetki_id):
    """Session önbelleğinden yetki kontrolü yapar; DB sorgusu atmaz."""
    return bool(session.get('kullanici_id')) and yetki_id in set(session.get('yetkiler', []))

def tablo_yetkili_mi(tablo_adi, kullanici_id):
    """Kullanıcının rolüne bu tablo atanmış mı? Atanmamışsa erişim engellenir."""
    try:
        yetkili = query("""
            SELECT rt.TablAdi FROM rol_tablo rt
            JOIN kullanici k ON k.RolID = rt.RolID
            WHERE k.KullaniciID = %s
        """, (kullanici_id,))
        yetkili_set = {r['TablAdi'] for r in yetkili}
        if not yetkili_set:
            return False
        return tablo_adi in yetkili_set
    except Exception:
        return False

# ─── DECORATOR'LAR ───────────────────────────────────────────────────────────

def login_gerekli(f):
    """Sayfa route'ları için login kontrolü; oturum yoksa /login'e yönlendirir."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('kullanici_id'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def yetki_gerekli(yetki_id):
    """Sayfa route'ları için yetki kontrolü; yetersizse 403 render eder."""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not has_yetki(yetki_id):
                return render_template('yetkisiz.html'), 403   # HTTP 403 (önceden 200 dönyordu)
            return f(*args, **kwargs)
        return decorated
    return decorator

def api_login_gerekli(f):
    """API endpoint'leri için login kontrolü; 401 JSON döner."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('kullanici_id'):
            return jsonify({'ok': False, 'msg': 'Oturum açmanız gerekiyor.'}), 401
        return f(*args, **kwargs)
    return decorated

def api_yetki_gerekli(yetki_id):
    """API endpoint'leri için yetki kontrolü; 403 JSON döner."""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not has_yetki(yetki_id):
                return jsonify({'ok': False, 'msg': 'Bu işlem için yetkiniz yok.'}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator

# ─── AUDIT LOG ───────────────────────────────────────────────────────────────

def audit(action: str, detail: str = ''):
    """
    Kritik işlemleri audit_log tablosuna kaydeder.
    Başarısız olursa sadece uygulama loguna yazar; ana işlemi engellemez.

    Args:
        action: İşlem kodu (örn. 'LOGIN', 'USER_DELETE', 'TABLE_DROP')
        detail: Ek bilgi (örn. silinen kayıt ID'si)
    """
    try:
        from datetime import datetime
        kullanici_id = session.get('kullanici_id', 'SYSTEM')
        ip = request.remote_addr or 'unknown'
        execute("""
            INSERT INTO audit_log (KullaniciID, IslemKodu, Detay, IP, IslemTarihi)
            VALUES (%s, %s, %s, %s, %s)
        """, (kullanici_id, action, detail[:500], ip, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    except Exception as e:
        logger.error(f'Audit log yazılamadı: {e} | action={action} detail={detail}')

# ─── HATA HANDLER'LARI ────────────────────────────────────────────────────────

@app.errorhandler(400)
def bad_request(e):
    if request.path.startswith('/api/'):
        return jsonify({'ok': False, 'msg': 'Geçersiz istek.'}), 400
    return render_template('error.html', kod=400, mesaj='Geçersiz İstek',
                           aciklama='Gönderilen istek işlenemedi.'), 400

@app.errorhandler(403)
def forbidden(e):
    if request.path.startswith('/api/'):
        return jsonify({'ok': False, 'msg': 'Erişim reddedildi.'}), 403
    return render_template('error.html', kod=403, mesaj='Erişim Reddedildi',
                           aciklama='Bu sayfaya erişim yetkiniz bulunmuyor.'), 403

@app.errorhandler(404)
def not_found(e):
    if request.path.startswith('/api/'):
        return jsonify({'ok': False, 'msg': 'Kaynak bulunamadı.'}), 404
    return render_template('error.html', kod=404, mesaj='Sayfa Bulunamadı',
                           aciklama='Aradığınız sayfa mevcut değil veya taşınmış olabilir.'), 404

@app.errorhandler(413)
def too_large(e):
    return jsonify({'ok': False, 'msg': 'Dosya boyutu 16 MB sınırını aşıyor.'}), 413

@app.errorhandler(429)
def too_many_requests(e):
    return jsonify({'ok': False, 'msg': 'Çok fazla istek gönderildi. Lütfen bekleyin.'}), 429

@app.errorhandler(500)
def server_error(e):
    logger.exception(f'500 Sunucu Hatası: {e}')
    if request.path.startswith('/api/'):
        return jsonify({'ok': False, 'msg': 'Sunucu hatası oluştu.'}), 500
    return render_template('error.html', kod=500, mesaj='Sunucu Hatası',
                           aciklama='Beklenmedik bir hata oluştu. Lütfen daha sonra tekrar deneyin.'), 500

# ─── CSRF TOKEN — şablonlara global eriş ─────────────────────────────────────

@app.context_processor
def inject_globals():
    """Her şablona csrf_token ve yetkiler değişkenlerini enjekte eder."""
    return {
        'csrf_token': generate_csrf_token(),
        'yetkiler':   set(session.get('yetkiler', [])),
        'kullanici_adi': session.get('kullanici_adi', ''),
    }

# ─── AUTH ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    if not session.get('kullanici_id'):
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/api/connect', methods=['POST'])
def api_connect():
    """MySQL bağlantısını test eder ve konfigürasyonu session'a kaydeder."""
    d = request.json
    if not d:
        return jsonify({'ok': False, 'msg': 'Geçersiz istek.'}), 400

    # Zorunlu alan kontrolü
    for alan in ('host', 'port', 'user', 'password', 'database'):
        if not d.get(alan):
            return jsonify({'ok': False, 'msg': f'{alan} alanı zorunludur.'}), 400
    try:
        conn = mysql.connector.connect(
            host=d['host'], port=int(d['port']),
            user=d['user'], password=d['password'],
            database=d['database'], connect_timeout=5
        )
        conn.close()
        global _pool
        _pool = None
        session['db'] = d
        session.permanent = True   # Session timeout'u aktif et
        logger.info(f'DB bağlantısı başarılı: {d["user"]}@{d["host"]}/{d["database"]}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/login', methods=['POST'])
@rate_limit(max_requests=10, window_seconds=60)   # 10 deneme/dakika
def api_login():
    """
    Kullanıcı adı ve şifre ile oturum açar.
    Rate limited: 10 istek/dakika (brute-force koruması).
    """
    d = request.json
    if not d or not d.get('username') or not d.get('password'):
        return jsonify({'ok': False, 'msg': 'Kullanıcı adı ve şifre zorunludur.'}), 400
    try:
        row = query("SELECT * FROM kullanici WHERE KullaniciAdi=%s",
                    (d['username'].strip(),), fetchone=True)
        if not row:
            return jsonify({'ok': False, 'msg': 'Kullanıcı adı veya şifre hatalı.'})

        sifreli = row['KullaniciSifresi']
        if sifreli.startswith('$2b$') or sifreli.startswith('$2a$') or sifreli.startswith('scrypt:') or sifreli.startswith('pbkdf2:'):
            if not check_password_hash(sifreli, d['password']):
                logger.warning(f'Başarısız giriş: {d["username"]} IP={request.remote_addr}')
                return jsonify({'ok': False, 'msg': 'Kullanıcı adı veya şifre hatalı.'})
        else:
            # Geçiş dönemi: düz metin → doğrula ve hash'le
            if sifreli != d['password']:
                return jsonify({'ok': False, 'msg': 'Kullanıcı adı veya şifre hatalı.'})
            yeni_hash = generate_password_hash(d['password'])
            execute("UPDATE kullanici SET KullaniciSifresi=%s WHERE KullaniciID=%s",
                    (yeni_hash, row['KullaniciID']))

        session['kullanici_id']  = row['KullaniciID']
        session['kullanici_adi'] = row['KullaniciAdi']
        session['yetkiler']      = list(kullanici_yetkileri(row['KullaniciID']))
        session['csrf_token']    = secrets.token_hex(32)   # Giriş sonrası token yenile
        session.permanent        = True

        logger.info(f'Başarılı giriş: {row["KullaniciAdi"]} IP={request.remote_addr}')
        audit('LOGIN', f'Kullanıcı: {row["KullaniciAdi"]}')
        return jsonify({'ok': True})
    except Exception as e:
        logger.error(f'Login hatası: {e}')
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/logout')
def logout():
    """Oturumu sonlandırır, pool'u temizler, audit kaydı atar."""
    audit('LOGOUT', f'Kullanıcı: {session.get("kullanici_adi", "?")}')
    global _pool
    _pool = None
    session.clear()
    return redirect(url_for('login'))

# ─── ŞİFRE DEĞİŞTİR ─────────────────────────────────────────────────────────

@app.route('/sifre-degistir')
@login_gerekli
def sifre_degistir_page():
    """Şifre değiştirme sayfasını gösterir."""
    return render_template('sifre_degistir.html', kullanici_adi=session.get('kullanici_adi'))

@app.route('/api/sifre-degistir', methods=['POST'])
@api_login_gerekli
@csrf_protect
def api_sifre_degistir():
    """
    Oturum açmış kullanıcının kendi şifresini değiştirir.
    Mevcut şifreyi doğrular, yeni şifreye kompleksite kuralı uygular.
    """
    d = request.json
    if not d:
        return jsonify({'ok': False, 'msg': 'Geçersiz istek.'}), 400

    mevcut  = d.get('mevcut', '').strip()
    yeni    = d.get('yeni', '').strip()
    tekrar  = d.get('tekrar', '').strip()

    if not mevcut or not yeni or not tekrar:
        return jsonify({'ok': False, 'msg': 'Tüm alanlar zorunludur.'})
    if yeni != tekrar:
        return jsonify({'ok': False, 'msg': 'Yeni şifreler eşleşmiyor.'})

    hata = validate_password(yeni)
    if hata:
        return jsonify({'ok': False, 'msg': hata})

    try:
        kullanici_id = session.get('kullanici_id')
        row = query("SELECT KullaniciSifresi FROM kullanici WHERE KullaniciID=%s",
                    (kullanici_id,), fetchone=True)
        if not row:
            return jsonify({'ok': False, 'msg': 'Kullanıcı bulunamadı.'})

        sifreli = row['KullaniciSifresi']
        # Eski şifreyi doğrula (hash veya düz metin geçiş dönemi)
        if sifreli.startswith('$2b$') or sifreli.startswith('$2a$') or sifreli.startswith('scrypt:') or sifreli.startswith('pbkdf2:'):
            if not check_password_hash(sifreli, mevcut):
                return jsonify({'ok': False, 'msg': 'Mevcut şifre hatalı.'})
        else:
            if sifreli != mevcut:
                return jsonify({'ok': False, 'msg': 'Mevcut şifre hatalı.'})

        yeni_hash = generate_password_hash(yeni)
        execute("UPDATE kullanici SET KullaniciSifresi=%s WHERE KullaniciID=%s",
                (yeni_hash, kullanici_id))
        audit('PASSWORD_CHANGE', f'Kullanıcı: {session.get("kullanici_adi")}')
        logger.info(f'Şifre değiştirildi: {session.get("kullanici_adi")}')
        return jsonify({'ok': True})
    except Exception as e:
        logger.error(f'Şifre değiştirme hatası: {e}')
        return jsonify({'ok': False, 'msg': str(e)})

# ─── DASHBOARD ───────────────────────────────────────────────────────────────

@app.route('/dashboard')
@login_gerekli
def dashboard():
    yetkiler     = set(session.get('yetkiler', []))
    kullanici_id = session.get('kullanici_id')
    rol_tablolari = []
    try:
        rows = query("""
            SELECT rt.TablAdi FROM rol_tablo rt
            JOIN kullanici k ON k.RolID = rt.RolID
            WHERE k.KullaniciID = %s ORDER BY rt.TablAdi
        """, (kullanici_id,))
        rol_tablolari = [r['TablAdi'] for r in rows]
    except Exception:
        pass
    return render_template('dashboard.html', yetkiler=yetkiler,
                           kullanici_adi=session.get('kullanici_adi'),
                           rol_tablolari=rol_tablolari)

# ─── EXCEL → TABLO OLUŞTUR ───────────────────────────────────────────────────

@app.route('/excel-mysql-create')
@login_gerekli
@yetki_gerekli('Y000003')
def excel_mysql_create():
    return render_template('excel_mysql.html', kullanici_adi=session.get('kullanici_adi'))

@app.route('/api/excel-preview', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000003')
@csrf_protect
def api_excel_preview():
    """Excel dosyasını okur, sheet listesi + alan adlarını döner."""
    try:
        file      = request.files.get('file')
        sheet_idx = int(request.form.get('sheet', 0))
        header_row = int(request.form.get('header_row', 1))  # 1-indexed

        if not file:
            return jsonify({'success': False, 'message': 'Dosya seçilmedi.'})
        guvenli_ad = guvenli_dosya_adi(file.filename)
        if not guvenli_ad:
            return jsonify({'success': False, 'message': 'Geçerli bir Excel dosyası seçin (.xlsx, .xls).'})

        filepath = os.path.join(app.config['UPLOAD_FOLDER'], guvenli_ad)
        file.save(filepath)
        try:
            import openpyxl
            wb     = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
            sheets = wb.sheetnames
            wb.close()
            df = pd.read_excel(filepath, sheet_name=sheet_idx,
                               header=header_row - 1, dtype=str).fillna('')
        finally:
            if os.path.exists(filepath):
                os.remove(filepath)

        if df.empty or len(df.columns) == 0:
            return jsonify({'success': False, 'message': 'Excel dosyası boş veya sütun içermiyor.'})

        orijinal_ad = secure_filename(file.filename)
        table_name  = sanitize(os.path.splitext(orijinal_ad)[0])
        columns     = [sanitize(c) for c in df.columns.tolist() if c and not str(c).startswith('Unnamed')]
        row_count   = len(df)

        return jsonify({
            'success': True,
            'table': table_name,
            'columns': columns,
            'row_count': row_count,
            'sheets': sheets,
            'active_sheet': sheet_idx,
            'header_row': header_row
        })
    except Exception as e:
        logger.error(f'Excel önizleme hatası: {e}')
        return jsonify({'success': False, 'message': str(e)})


@app.route('/api/excel-upload', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000003')
@csrf_protect
def api_excel_upload():
    """Seçili alanlarla yeni MySQL tablosu oluşturur (JSON body)."""
    try:
        d          = request.get_json(force=True)
        table_name = sanitize(d.get('table', ''))
        columns    = [sanitize(c) for c in d.get('columns', []) if c]
        if not table_name:
            return jsonify({'success': False, 'message': 'Tablo adı boş.'})
        if not columns:
            return jsonify({'success': False, 'message': 'En az bir alan seçin.'})
        conn = get_conn()
        if not conn:
            return jsonify({'success': False, 'message': 'Veritabanı bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute(f"DROP TABLE IF EXISTS `{table_name}`")
        cols_def = ', '.join([f"`{c}` NVARCHAR(500)" for c in columns])
        cur.execute(f"CREATE TABLE `{table_name}` ({cols_def}) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        _tablo_log_kaydet(cur, table_name, session.get('kullanici_id'), 'OLUSTUR', 0, 0, 0)
        conn.commit()
        conn.close()
        audit('TABLE_CREATE', f'Tablo: {table_name}')
        logger.info(f'Tablo oluşturuldu: {table_name} ({len(columns)} sütun)')
        sql = f"CREATE TABLE `{table_name}` (\n  " + ',\n  '.join([f"`{c}` NVARCHAR(500)" for c in columns]) + "\n)"
        return jsonify({'success': True, 'message': f'"{table_name}" tablosu oluşturuldu!',
                        'table': table_name, 'columns': columns, 'sql': sql})
    except Exception as e:
        logger.error(f'Excel upload hatası: {e}')
        return jsonify({'success': False, 'message': str(e)})

# ─── EXCEL → MEVCUT TABLOYA YÜKLE ────────────────────────────────────────────

@app.route('/excel-mysql-load')
@login_gerekli
@yetki_gerekli('Y000004')
def excel_mysql_load():
    tables = []
    try:
        kullanici_id = session.get('kullanici_id')
        rows = query("""
            SELECT rt.TablAdi FROM rol_tablo rt
            JOIN kullanici k ON k.RolID = rt.RolID
            WHERE k.KullaniciID = %s ORDER BY rt.TablAdi
        """, (kullanici_id,))
        rol_tablolari = [r['TablAdi'] for r in rows]
        if rol_tablolari:
            tables = rol_tablolari
        else:
            conn = get_conn()
            cur  = conn.cursor(dictionary=True)
            cur.execute("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")
            tables = [list(r.values())[0] for r in cur.fetchall()]
            conn.close()
    except Exception as e:
        logger.error(f'Tablo listesi alınamadı: {e}')
    return render_template('excel_mysql_load.html',
                           kullanici_adi=session.get('kullanici_adi'), tables=tables)

@app.route('/api/table-columns/<table_name>')
@api_login_gerekli
@api_yetki_gerekli('Y000004')
def api_table_columns(table_name):
    """Tablo sütunlarını döner; yetki kontrolü yapılır."""
    kullanici_id = session.get('kullanici_id')
    if not tablo_yetkili_mi(table_name, kullanici_id):
        return jsonify({'ok': False, 'msg': 'Bu tabloya erişim yetkiniz yok.'}), 403
    try:
        conn = get_conn()
        cur  = conn.cursor(dictionary=True)
        cur.execute(f"SHOW COLUMNS FROM `{table_name}`")
        cols = [r['Field'] for r in cur.fetchall()]
        conn.close()
        return jsonify({'ok': True, 'columns': cols})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/excel-load', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000004')
@csrf_protect
def api_excel_load():
    """
    Excel dosyasını mevcut tabloya yükler.
    Append modunda büyük tablolar için batch işleme kullanılır (bellek dostu).
    """
    try:
        from datetime import datetime

        file       = request.files.get('file')
        table_name = request.form.get('table_name', '').strip()
        mode       = request.form.get('mode', 'append')

        if not file:
            return jsonify({'success': False, 'message': 'Dosya seçilmedi.'})
        guvenli_ad = guvenli_dosya_adi(file.filename)
        if not guvenli_ad:
            return jsonify({'success': False, 'message': 'Geçerli bir Excel dosyası seçin (.xlsx, .xls).'})
        if not table_name:
            return jsonify({'success': False, 'message': 'Tablo seçilmedi.'})

        kullanici_id = session.get('kullanici_id')
        if not tablo_yetkili_mi(table_name, kullanici_id):
            return jsonify({'success': False, 'message': 'Bu tabloya erişim yetkiniz yok.'})

        filepath = os.path.join(app.config['UPLOAD_FOLDER'], guvenli_ad)
        file.save(filepath)
        try:
            df = pd.read_excel(filepath, header=0, dtype=str).fillna('')
        finally:
            if os.path.exists(filepath):
                os.remove(filepath)

        if df.empty:
            return jsonify({'success': False, 'message': 'Excel dosyası boş.'})

        conn = get_conn()
        if not conn:
            return jsonify({'success': False, 'message': 'Veritabanı bağlantısı kurulamadı.'})
        cur = conn.cursor(dictionary=True)

        # ETL_DATE sütununu ekle
        cur.execute(f"SHOW COLUMNS FROM `{table_name}`")
        db_cols = [r['Field'] for r in cur.fetchall()]
        if 'ETL_DATE' not in db_cols:
            cur.execute(f"ALTER TABLE `{table_name}` ADD COLUMN `ETL_DATE` NVARCHAR(30)")
            conn.commit()
            db_cols.append('ETL_DATE')

        # Sütun eşleştirme (case-insensitive)
        db_cols_lower = {c.lower(): c for c in db_cols}
        matched_pairs = []
        for ec in df.columns:
            if ec in db_cols and ec != 'ETL_DATE':
                matched_pairs.append((ec, ec))
            elif ec.lower() in db_cols_lower and db_cols_lower[ec.lower()] != 'ETL_DATE':
                matched_pairs.append((ec, db_cols_lower[ec.lower()]))
        matched = [dc for _, dc in matched_pairs]

        if not matched:
            conn.close()
            return jsonify({'success': False, 'message': 'Excel sütunları tablo sütunlarıyla eşleşmedi.'})

        etl_date      = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        insert_count  = 0
        skip_count    = 0
        duplicate_count = 0

        all_cols    = matched + ['ETL_DATE']
        col_list    = ', '.join([f'`{c}`' for c in all_cols])
        placeholders = ', '.join(['%s'] * len(all_cols))
        ins_sql     = f"INSERT INTO `{table_name}` ({col_list}) VALUES ({placeholders})"

        cur2 = conn.cursor()   # DML için dictionary=False cursor

        if mode == 'truncate':
            cur2.execute(f"TRUNCATE TABLE `{table_name}`")
            conn.commit()
            for _, row in df.iterrows():
                try:
                    vals = [str(row[ec]) for ec, _ in matched_pairs] + [etl_date]
                    cur2.execute(ins_sql, vals)
                    insert_count += 1
                except Exception:
                    skip_count += 1
        else:
            # --- Büyük tablo dostu duplicate kontrolü ---
            # Tüm tabloyu RAM'e almak yerine, yalnızca eşleşen sütunların hash'ini çek
            col_list_sel = ', '.join([f'`{c}`' for c in matched])
            cur.execute(f"SELECT {col_list_sel} FROM `{table_name}`")
            existing_set = set()
            while True:
                batch = cur.fetchmany(5000)   # 5000'er satır çek
                if not batch:
                    break
                for er in batch:
                    existing_set.add(tuple(str(er.get(dc, '')) for dc in matched))

            for _, row in df.iterrows():
                try:
                    vals      = [str(row[ec]) for ec, _ in matched_pairs]
                    row_tuple = tuple(vals)
                    if row_tuple in existing_set:
                        duplicate_count += 1
                        continue
                    cur2.execute(ins_sql, vals + [etl_date])
                    existing_set.add(row_tuple)
                    insert_count += 1
                except Exception:
                    skip_count += 1

        _tablo_log_kaydet(cur2, table_name, kullanici_id, 'YUKLE', insert_count, skip_count, duplicate_count)
        conn.commit()
        conn.close()

        audit('TABLE_LOAD', f'Tablo: {table_name}, Mod: {mode}, Eklenen: {insert_count}')
        msg = f'{insert_count} yeni satır eklendi.'
        if duplicate_count: msg += f' {duplicate_count} tekrar atlandı.'
        if skip_count:      msg += f' {skip_count} hatalı atlandı.'
        return jsonify({'success': True, 'message': msg, 'table': table_name,
                        'inserted': insert_count, 'skipped': skip_count,
                        'duplicates': duplicate_count, 'matched_cols': matched,
                        'etl_date': etl_date})
    except Exception as e:
        logger.error(f'Excel load hatası: {e}')
        return jsonify({'success': False, 'message': str(e)})

# ─── TABLO GÖRÜNTÜLE ─────────────────────────────────────────────────────────

@app.route('/tablo-goruntule')
@login_gerekli
@yetki_gerekli('Y000004')
def tablo_goruntule():
    """Tablodaki verileri önizleme olarak gösterir (ilk 100 satır)."""
    kullanici_id  = session.get('kullanici_id')
    rol_tablolari = []
    try:
        rows = query("""
            SELECT rt.TablAdi FROM rol_tablo rt
            JOIN kullanici k ON k.RolID = rt.RolID
            WHERE k.KullaniciID = %s ORDER BY rt.TablAdi
        """, (kullanici_id,))
        rol_tablolari = [r['TablAdi'] for r in rows]
    except Exception:
        pass
    return render_template('tablo_goruntule.html',
                           kullanici_adi=session.get('kullanici_adi'),
                           tables=rol_tablolari)

@app.route('/api/tablo-data/<table_name>')
@api_login_gerekli
@api_yetki_gerekli('Y000004')
def api_tablo_data(table_name):
    """Tablonun ilk 100 satırını ve sütun listesini döner."""
    kullanici_id = session.get('kullanici_id')
    if not tablo_yetkili_mi(table_name, kullanici_id):
        return jsonify({'ok': False, 'msg': 'Bu tabloya erişim yetkiniz yok.'}), 403
    try:
        conn = get_conn()
        cur  = conn.cursor(dictionary=True)
        cur.execute(f"SHOW COLUMNS FROM `{table_name}`")
        cols = [r['Field'] for r in cur.fetchall()]
        cur.execute(f"SELECT * FROM `{table_name}` LIMIT 100")
        rows = cur.fetchall()
        cur.execute(f"SELECT COUNT(*) as cnt FROM `{table_name}`")
        total = cur.fetchone()['cnt']
        conn.close()
        return jsonify({'ok': True, 'columns': cols, 'rows': rows, 'total': total})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── TABLO EXPORT (Excel indir) ───────────────────────────────────────────────

@app.route('/api/tablo-export/<table_name>')
@api_login_gerekli
@api_yetki_gerekli('Y000004')
def api_tablo_export(table_name):
    """
    Tablonun tüm verisini Excel olarak indirir.
    pandas to_excel ile streaming Response oluşturur.
    """
    kullanici_id = session.get('kullanici_id')
    if not tablo_yetkili_mi(table_name, kullanici_id):
        return jsonify({'ok': False, 'msg': 'Bu tabloya erişim yetkiniz yok.'}), 403
    try:
        import io
        conn = get_conn()
        cur  = conn.cursor(dictionary=True)
        cur.execute(f"SELECT * FROM `{table_name}`")
        rows = cur.fetchall()
        conn.close()

        if not rows:
            return jsonify({'ok': False, 'msg': 'Tabloda veri yok.'}), 404

        df  = pd.DataFrame(rows)
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name=table_name[:31])
        buf.seek(0)

        audit('TABLE_EXPORT', f'Tablo: {table_name}, Satır: {len(rows)}')
        return Response(
            buf.getvalue(),
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={'Content-Disposition': f'attachment; filename="{table_name}.xlsx"'}
        )
    except Exception as e:
        logger.error(f'Tablo export hatası: {e}')
        return jsonify({'ok': False, 'msg': str(e)})

# ─── TABLO SİL ───────────────────────────────────────────────────────────────

@app.route('/tablo-sil')
@login_gerekli
@yetki_gerekli('Y000005')
def tablo_sil_page():
    tables = []
    try:
        kullanici_id  = session.get('kullanici_id')
        rows = query("""
            SELECT rt.TablAdi FROM rol_tablo rt
            JOIN kullanici k ON k.RolID = rt.RolID
            WHERE k.KullaniciID = %s ORDER BY rt.TablAdi
        """, (kullanici_id,))
        rol_tablolari = [r['TablAdi'] for r in rows]
        is_admin = admin_mi(kullanici_id)
        if rol_tablolari:
            tables = rol_tablolari
        else:
            conn = get_conn()
            cur  = conn.cursor(dictionary=True)
            cur.execute("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")
            tables = [list(r.values())[0] for r in cur.fetchall()]
            conn.close()
        # Admin değilse sistem tablolarını gizle
        if not is_admin:
            tables = [t for t in tables if t not in KORUNAN_SISTEM_TABLOLARI]
    except Exception as e:
        logger.error(f'Tablo sil sayfa hatası: {e}')
    return render_template('tablo_sil.html', kullanici_adi=session.get('kullanici_adi'), tables=tables)

@app.route('/api/tablo-sil', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000005')
@csrf_protect
def api_tablo_sil():
    d        = request.json
    tablolar = d.get('tablolar', []) if d else []
    if not tablolar:
        return jsonify({'ok': False, 'msg': 'Silinecek tablo seçilmedi.'})

    kullanici_id = session.get('kullanici_id')
    try:
        yetkili = {r['TablAdi'] for r in query("""
            SELECT rt.TablAdi FROM rol_tablo rt
            JOIN kullanici k ON k.RolID = rt.RolID
            WHERE k.KullaniciID = %s
        """, (kullanici_id,))}
    except Exception as e:
        return jsonify({'ok': False, 'msg': f'Yetki kontrolü başarısız: {e}'})

    conn = get_conn()
    if not conn:
        return jsonify({'ok': False, 'msg': 'Veritabanı bağlantısı kurulamadı.'})
    cur = conn.cursor()

    # Sistem tablolarını koruma: admin değilse engellenebilir, admin ise çift onay
    kullanici_id_check = session.get('kullanici_id')
    if not admin_mi(kullanici_id_check):
        sistem_tablolari = [t for t in tablolar if t in KORUNAN_SISTEM_TABLOLARI]
        if sistem_tablolari:
            return jsonify({'ok': False, 'msg': f'Sistem tabloları silinemez: {", ".join(sistem_tablolari)}'})

    silinen, hatalar = [], []
    for tablo in tablolar:
        if yetkili and tablo not in yetkili:
            hatalar.append(f'{tablo}: yetki yok')
            continue
        try:
            cur.execute(f"DROP TABLE IF EXISTS `{tablo}`")
            _tablo_log_kaydet(cur, tablo, kullanici_id, 'SIL', 0, 0, 0)
            audit('TABLE_DROP', f'Tablo: {tablo}')
            silinen.append(tablo)
        except Exception as e:
            hatalar.append(f'{tablo}: {str(e)}')

    conn.commit()
    conn.close()
    logger.info(f'Tablo silme: silinen={silinen} hatalar={hatalar}')
    return jsonify({'ok': True, 'silinen': silinen, 'hatalar': hatalar})

# ─── KULLANICI YÖNETİMİ ──────────────────────────────────────────────────────

@app.route('/kullanicilar')
@login_gerekli
@yetki_gerekli('Y000001')
def kullanicilar():
    return render_template('kullanicilar.html', kullanici_adi=session.get('kullanici_adi'))

@app.route('/api/kullanicilar')
@api_login_gerekli
@api_yetki_gerekli('Y000001')
def api_kullanicilar_list():
    """Şifre hash'i hariç kullanıcı listesi (sayfalı)."""
    page     = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 50, type=int), 200)
    offset   = (page - 1) * per_page
    # KullaniciSifresi sütunu bilinçli olarak hariç tutuldu
    rows  = query("""
        SELECT k.KullaniciID, k.KullaniciAdi, k.KullaniciEposta, k.RolID, r.RolAdi
        FROM kullanici k LEFT JOIN rol r ON k.RolID = r.RolID
        ORDER BY k.KullaniciID LIMIT %s OFFSET %s
    """, (per_page, offset))
    total = query("SELECT COUNT(*) as cnt FROM kullanici", fetchone=True)['cnt']
    return jsonify({'rows': rows, 'total': total, 'page': page, 'per_page': per_page})

@app.route('/api/kullanicilar', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000001')
@csrf_protect
def api_kullanici_ekle():
    d = request.json
    if not d:
        return jsonify({'ok': False, 'msg': 'Geçersiz istek.'}), 400

    # Zorunlu alan kontrolü
    ad     = (d.get('KullaniciAdi') or '').strip()
    sifre  = (d.get('KullaniciSifresi') or '').strip()
    eposta = (d.get('KullaniciEposta') or '').strip()
    rol_id = (d.get('RolID') or '').strip()

    if not ad:
        return jsonify({'ok': False, 'msg': 'Kullanıcı adı zorunludur.'})
    if len(ad) < 3:
        return jsonify({'ok': False, 'msg': 'Kullanıcı adı en az 3 karakter olmalıdır.'})
    if not sifre:
        return jsonify({'ok': False, 'msg': 'Şifre zorunludur.'})
    hata = validate_password(sifre)
    if hata:
        return jsonify({'ok': False, 'msg': hata})
    if not validate_email(eposta):
        return jsonify({'ok': False, 'msg': 'Geçersiz e-posta formatı.'})
    if not rol_id:
        return jsonify({'ok': False, 'msg': 'Rol seçilmesi zorunludur.'})

    try:
        # Kullanıcı adı mükerrer kontrolü
        mevcut = query("SELECT KullaniciID FROM kullanici WHERE KullaniciAdi=%s",
                       (ad,), fetchone=True)
        if mevcut:
            return jsonify({'ok': False, 'msg': 'Bu kullanıcı adı zaten kullanılıyor.'})

        last   = query("SELECT KullaniciID FROM kullanici ORDER BY KullaniciID DESC LIMIT 1", fetchone=True)
        num    = int(last['KullaniciID'][1:]) + 1 if last else 1
        new_id = f'K{num:06d}'
        hashed = generate_password_hash(sifre)

        execute("INSERT INTO kullanici (KullaniciID,KullaniciAdi,KullaniciSifresi,KullaniciEposta,RolID) VALUES (%s,%s,%s,%s,%s)",
                (new_id, ad, hashed, eposta, rol_id))
        audit('USER_CREATE', f'Yeni kullanıcı: {ad} (ID: {new_id})')
        logger.info(f'Kullanıcı eklendi: {ad}')
        return jsonify({'ok': True, 'id': new_id})
    except Exception as e:
        logger.error(f'Kullanıcı ekleme hatası: {e}')
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/kullanicilar/<kid>', methods=['PUT'])
@api_login_gerekli
@api_yetki_gerekli('Y000001')
@csrf_protect
def api_kullanici_guncelle(kid):
    d = request.json
    if not d:
        return jsonify({'ok': False, 'msg': 'Geçersiz istek.'}), 400

    ad     = (d.get('KullaniciAdi') or '').strip()
    sifre  = (d.get('KullaniciSifresi') or '').strip()
    eposta = (d.get('KullaniciEposta') or '').strip()
    rol_id = (d.get('RolID') or '').strip()

    if not ad or len(ad) < 3:
        return jsonify({'ok': False, 'msg': 'Kullanıcı adı en az 3 karakter olmalıdır.'})
    if sifre:
        hata = validate_password(sifre)
        if hata:
            return jsonify({'ok': False, 'msg': hata})
    if not validate_email(eposta):
        return jsonify({'ok': False, 'msg': 'Geçersiz e-posta formatı.'})
    if not rol_id:
        return jsonify({'ok': False, 'msg': 'Rol seçilmesi zorunludur.'})

    try:
        if sifre:
            hashed = generate_password_hash(sifre)
            execute("UPDATE kullanici SET KullaniciAdi=%s,KullaniciSifresi=%s,KullaniciEposta=%s,RolID=%s WHERE KullaniciID=%s",
                    (ad, hashed, eposta, rol_id, kid))
        else:
            execute("UPDATE kullanici SET KullaniciAdi=%s,KullaniciEposta=%s,RolID=%s WHERE KullaniciID=%s",
                    (ad, eposta, rol_id, kid))
        audit('USER_UPDATE', f'Kullanıcı güncellendi: ID={kid}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/kullanicilar/<kid>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000001')
@csrf_protect
def api_kullanici_sil(kid):
    if kid == session.get('kullanici_id'):
        return jsonify({'ok': False, 'msg': 'Kendi hesabınızı silemezsiniz.'})
    try:
        satir = query("SELECT KullaniciAdi FROM kullanici WHERE KullaniciID=%s", (kid,), fetchone=True)
        execute("DELETE FROM kullanici WHERE KullaniciID=%s", (kid,))
        audit('USER_DELETE', f'Kullanıcı silindi: {satir["KullaniciAdi"] if satir else kid}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── ROL YÖNETİMİ ────────────────────────────────────────────────────────────

@app.route('/roller')
@login_gerekli
@yetki_gerekli('Y000002')
def roller():
    return render_template('roller.html', kullanici_adi=session.get('kullanici_adi'))

@app.route('/api/roller')
@api_login_gerekli
@api_yetki_gerekli('Y000002')
def api_roller_list():
    rows = query("SELECT * FROM rol ORDER BY RolID")
    for r in rows:
        r['yetkiler'] = query("""SELECT y.YetkiID,y.YetkiAdi FROM rol_yetki ry
                                  JOIN yetki y ON ry.YetkiID=y.YetkiID WHERE ry.RolID=%s""", (r['RolID'],))
        try:
            r['tablolar'] = [t['TablAdi'] for t in query("SELECT TablAdi FROM rol_tablo WHERE RolID=%s", (r['RolID'],))]
        except Exception:
            r['tablolar'] = []
    return jsonify(rows)

@app.route('/api/roller', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000002')
@csrf_protect
def api_rol_ekle():
    d = request.json
    if not d or not (d.get('RolAdi') or '').strip():
        return jsonify({'ok': False, 'msg': 'Rol adı zorunludur.'})
    last   = query("SELECT RolID FROM rol ORDER BY RolID DESC LIMIT 1", fetchone=True)
    num    = int(last['RolID'][1:]) + 1 if last else 1
    new_id = f'R{num:06d}'
    try:
        execute("INSERT INTO rol (RolID,RolAdi) VALUES (%s,%s)", (new_id, d['RolAdi'].strip()))
        for yid in d.get('yetkiler', []):
            execute("INSERT INTO rol_yetki (RolID,YetkiID) VALUES (%s,%s)", (new_id, yid))
        _save_tablolar(new_id, d.get('tablolar', []))
        audit('ROLE_CREATE', f'Rol: {d["RolAdi"]} (ID: {new_id})')
        return jsonify({'ok': True, 'id': new_id})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/roller/<rid>', methods=['PUT'])
@api_login_gerekli
@api_yetki_gerekli('Y000002')
@csrf_protect
def api_rol_guncelle(rid):
    d = request.json
    if not d or not (d.get('RolAdi') or '').strip():
        return jsonify({'ok': False, 'msg': 'Rol adı zorunludur.'})
    try:
        execute("UPDATE rol SET RolAdi=%s WHERE RolID=%s", (d['RolAdi'].strip(), rid))
        execute("DELETE FROM rol_yetki WHERE RolID=%s", (rid,))
        for yid in d.get('yetkiler', []):
            execute("INSERT INTO rol_yetki (RolID,YetkiID) VALUES (%s,%s)", (rid, yid))
        _save_tablolar(rid, d.get('tablolar', []))
        audit('ROLE_UPDATE', f'Rol güncellendi: ID={rid}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

def _save_tablolar(rol_id, tablolar):
    """Role atanan tablo listesini günceller (DELETE + INSERT)."""
    conn = get_conn()
    if not conn:
        raise RuntimeError('Veritabanı bağlantısı kurulamadı.')
    cur = conn.cursor()
    cur.execute("DELETE FROM rol_tablo WHERE RolID=%s", (rol_id,))
    for t in tablolar:
        cur.execute("INSERT INTO rol_tablo (RolID,TablAdi) VALUES (%s,%s)", (rol_id, t))
    conn.commit()
    conn.close()

@app.route('/api/roller/<rid>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000002')
@csrf_protect
def api_rol_sil(rid):
    try:
        execute("DELETE FROM rol WHERE RolID=%s", (rid,))
        audit('ROLE_DELETE', f'Rol silindi: ID={rid}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── YETKİ YÖNETİMİ ──────────────────────────────────────────────────────────

@app.route('/yetkiler')
@login_gerekli
@yetki_gerekli('Y000002')
def yetkiler_page():
    return render_template('yetkiler.html', kullanici_adi=session.get('kullanici_adi'))

@app.route('/api/yetkiler')
@api_login_gerekli
@api_yetki_gerekli('Y000002')
def api_yetkiler_list():
    return jsonify(query("SELECT * FROM yetki ORDER BY YetkiID"))

@app.route('/api/yetkiler', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000002')
@csrf_protect
def api_yetki_ekle():
    d = request.json
    if not d or not (d.get('YetkiAdi') or '').strip():
        return jsonify({'ok': False, 'msg': 'Yetki adı zorunludur.'})
    last   = query("SELECT YetkiID FROM yetki ORDER BY YetkiID DESC LIMIT 1", fetchone=True)
    num    = int(last['YetkiID'][1:]) + 1 if last else 1
    new_id = f'Y{num:06d}'
    try:
        execute("INSERT INTO yetki (YetkiID,YetkiAdi) VALUES (%s,%s)", (new_id, d['YetkiAdi'].strip()))
        return jsonify({'ok': True, 'id': new_id})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/yetkiler/<yid>', methods=['PUT'])
@api_login_gerekli
@api_yetki_gerekli('Y000002')
@csrf_protect
def api_yetki_guncelle(yid):
    d = request.json
    if not d or not (d.get('YetkiAdi') or '').strip():
        return jsonify({'ok': False, 'msg': 'Yetki adı zorunludur.'})
    try:
        execute("UPDATE yetki SET YetkiAdi=%s WHERE YetkiID=%s", (d['YetkiAdi'].strip(), yid))
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/yetkiler/<yid>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000002')
@csrf_protect
def api_yetki_sil(yid):
    try:
        execute("DELETE FROM yetki WHERE YetkiID=%s", (yid,))
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── DROPDOWN API'LERİ ───────────────────────────────────────────────────────

@app.route('/api/roller/all')
@api_login_gerekli
def api_roller_all():
    return jsonify(query("SELECT * FROM rol ORDER BY RolID"))

@app.route('/api/yetkiler/all')
@api_login_gerekli
def api_yetkiler_all():
    return jsonify(query("SELECT * FROM yetki ORDER BY YetkiID"))

@app.route('/api/tables/all')
@api_login_gerekli
def api_tables_all():
    try:
        conn = get_conn()
        cur  = conn.cursor(dictionary=True)
        cur.execute("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")
        tables = [list(r.values())[0] for r in cur.fetchall()]
        conn.close()
        return jsonify({'ok': True, 'tables': tables})
    except Exception as e:
        return jsonify({'ok': False, 'tables': [], 'msg': str(e)})

# ─── CSRF TOKEN API'si ────────────────────────────────────────────────────────

@app.route('/api/csrf-token')
@api_login_gerekli
def api_csrf_token():
    """
    SPA / fetch tabanlı sayfalara güncel CSRF token'ı sağlar.
    Her sayfa yüklenişinde çağrılabilir.
    """
    return jsonify({'token': generate_csrf_token()})

# ─── TABLO LOG ───────────────────────────────────────────────────────────────

def _tablo_log_kaydet(cur, tablo_adi, kullanici_id, islem_turu, eklenen, atlanan, tekrar):
    """Her tablo işleminde tablo_log tablosuna kayıt atar (mevcut cursor ile)."""
    try:
        from datetime import datetime
        cur.execute("""INSERT INTO tablo_log
            (Tablo, KullaniciID, IslemTuru, Eklenen, Atlanan, Tekrar, IslemTarihi)
            VALUES (%s,%s,%s,%s,%s,%s,%s)""",
            (tablo_adi, kullanici_id, islem_turu, eklenen, atlanan, tekrar,
             datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    except Exception as e:
        logger.error(f'Tablo log yazılamadı: {e}')

@app.route('/api/tablo-log/<path:tablo_adi>')
@api_login_gerekli
def api_tablo_log(tablo_adi):
    try:
        rows = query("""
            SELECT tl.LogID,tl.IslemTuru,tl.Eklenen,tl.Atlanan,tl.Tekrar,
                   tl.IslemTarihi,k.KullaniciAdi
            FROM tablo_log tl
            LEFT JOIN kullanici k ON tl.KullaniciID=k.KullaniciID
            WHERE tl.Tablo=%s ORDER BY tl.IslemTarihi DESC LIMIT 100
        """, (tablo_adi,))
        return jsonify({'ok': True, 'log': rows})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/tablo-info/<path:tablo_adi>')
@api_login_gerekli
def api_tablo_info(tablo_adi):
    try:
        ilk = query("""SELECT tl.IslemTarihi,k.KullaniciAdi FROM tablo_log tl
                       LEFT JOIN kullanici k ON tl.KullaniciID=k.KullaniciID
                       WHERE tl.Tablo=%s AND tl.IslemTuru='OLUSTUR'
                       ORDER BY tl.IslemTarihi ASC LIMIT 1""", (tablo_adi,), fetchone=True)
        son = query("""SELECT tl.IslemTarihi,k.KullaniciAdi,tl.Eklenen FROM tablo_log tl
                       LEFT JOIN kullanici k ON tl.KullaniciID=k.KullaniciID
                       WHERE tl.Tablo=%s AND tl.IslemTuru='YUKLE'
                       ORDER BY tl.IslemTarihi DESC LIMIT 1""", (tablo_adi,), fetchone=True)
        return jsonify({'ok': True, 'ilk': ilk, 'son': son})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── AUDIT LOG ───────────────────────────────────────────────────────────────

@app.route('/audit-log')
@login_gerekli
@yetki_gerekli('Y000001')
def audit_log_page():
    return render_template('audit_log.html',
                           kullanici_adi=session.get('kullanici_adi'),
                           yetkiler=set(session.get('yetkiler', [])))

@app.route('/api/audit-log')
@api_login_gerekli
@api_yetki_gerekli('Y000001')
def api_audit_log():
    """Son 200 audit kaydını döner (sadece Y000001 yetkisi ile erişilebilir)."""
    try:
        rows = query("""
            SELECT al.LogID, al.KullaniciID, k.KullaniciAdi, al.IslemKodu,
                   al.Detay, al.IP, al.IslemTarihi
            FROM audit_log al
            LEFT JOIN kullanici k ON al.KullaniciID = k.KullaniciID
            ORDER BY al.IslemTarihi DESC LIMIT 200
        """)
        return jsonify({'ok': True, 'log': rows})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── DASHBOARD TERCİHLERİ ────────────────────────────────────────────────────

@app.route('/api/dashboard-tercih')
@api_login_gerekli
def api_dashboard_tercih_get():
    try:
        conn = get_conn()
        cur  = conn.cursor(dictionary=True)
        cur.execute("SELECT TercihDeger FROM kullanici_tercih WHERE KullaniciID=%s AND TercihAnahtar='dashboard_kartlar'",
                    (session['kullanici_id'],))
        row = cur.fetchone()
        conn.close()
        return jsonify({'ok': True, 'deger': row['TercihDeger'] if row else None})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/dashboard-tercih', methods=['POST'])
@api_login_gerekli
@csrf_protect
def api_dashboard_tercih_set():
    d = request.json
    if not d or 'deger' not in d:
        return jsonify({'ok': False, 'msg': 'Geçersiz istek.'}), 400
    try:
        conn = get_conn()
        cur  = conn.cursor()
        cur.execute("""INSERT INTO kullanici_tercih (KullaniciID,TercihAnahtar,TercihDeger)
                       VALUES (%s,'dashboard_kartlar',%s)
                       ON DUPLICATE KEY UPDATE TercihDeger=%s""",
                    (session['kullanici_id'], d['deger'], d['deger']))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ─── YARDIM ──────────────────────────────────────────────────────────────────

@app.route('/yardim')
@login_gerekli
def yardim():
    return render_template('help.html', kullanici_adi=session.get('kullanici_adi'),
                           yetkiler=set(session.get('yetkiler', [])))

# ─── UYGULAMA BAŞLATMA ───────────────────────────────────────────────────────

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    debug_mode = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    app.run(debug=debug_mode, port=5000)

# ─── DİZİN YÖNETİMİ ──────────────────────────────────────────────────────────

def dizin_id_uret():
    rows = query("SELECT DizinID FROM dizin ORDER BY DizinID DESC LIMIT 1")
    if not rows:
        return 'D000001'
    last = rows[0]['DizinID']
    return f"D{int(last[1:])+1:06d}"

def kullanici_dizin_yetkileri(kullanici_id):
    """Kullanıcının erişebildiği dizin ID listesini döner (rol + kişisel yetki)."""
    rol_id = session.get('rol_id')
    rows = query("""
        SELECT DISTINCT DizinID FROM dizin_yetki
        WHERE RolID = %s OR KullaniciID = %s
    """, (rol_id, kullanici_id))
    return {r['DizinID'] for r in rows}


def kullanici_dizinleri(kullanici_id, rol_id, sadece_yazma=False):
    """kullanici_dizin_yetkileri için uyumlu alias (YetkiTuru filtreli)."""
    yetki_filtre = "AND YetkiTuru='yazma'" if sadece_yazma else ""
    rows = query(f"""
        SELECT DISTINCT DizinID FROM dizin_yetki
        WHERE (RolID = %s OR KullaniciID = %s) {yetki_filtre}
    """, (rol_id, kullanici_id))
    return {r['DizinID'] for r in rows}

def bildirim_gonder(alici_id, tip, baslik, mesaj=None, dosya_id=None):
    """Sisteme bildirim ekler."""
    try:
        conn = get_conn()
        if not conn: return
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO bildirim (AliciID, Tip, Baslik, Mesaj, DosyaID)
            VALUES (%s, %s, %s, %s, %s)
        """, (alici_id, tip, baslik, mesaj, dosya_id))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f'Bildirim gönderilemedi: {e}')


# ═══════════════════════════════════════════════════════════════════════════════
# MODÜL 5 — DOSYA ONAY SONRASI DB AKTARIM
# ═══════════════════════════════════════════════════════════════════════════════

def _sp_calistir(conn, sp_adi):
    """Stored procedure çalıştırır. sp_adi sanitize edilmiş olmalı."""
    cur = conn.cursor()
    cur.callproc(sp_adi)
    for _ in cur.stored_results():
        pass
    conn.commit()
    cur.close()


def _kalite_kontrol_calistir(conn, tablo_adi):
    """
    Tablonun aktif kalite kurallarını çalıştırır.
    Döner: {'gecti': bool, 'sonuclar': [...], 'hata_sayisi': int, 'uyari_sayisi': int}
    """
    cur = conn.cursor(dictionary=True)
    cur.execute(
        "SELECT * FROM kalite_kural WHERE TabloAdi=%s AND AktifMi=1",
        (tablo_adi,)
    )
    kurallar = cur.fetchall()
    cur.close()

    sonuclar    = []
    hata_sayisi = 0
    uyari_sayisi = 0

    for k in kurallar:
        sutun   = k['SutunAdi']
        tip     = k['KuralTipi']
        deger   = k['KuralDeger'] or ''
        seviye  = k['HataSeviyesi']  # 'hata' veya 'uyari'
        ihlal   = 0

        try:
            c2 = conn.cursor()
            if tip == 'bos_deger':
                c2.execute(
                    f"SELECT COUNT(*) FROM `{tablo_adi}` "
                    f"WHERE `{sutun}` IS NULL OR TRIM(`{sutun}`)=''")
                ihlal = c2.fetchone()[0]

            elif tip == 'uzunluk' and deger.isdigit():
                c2.execute(
                    f"SELECT COUNT(*) FROM `{tablo_adi}` "
                    f"WHERE CHAR_LENGTH(`{sutun}`) > %s", (int(deger),))
                ihlal = c2.fetchone()[0]

            elif tip == 'format' and deger:
                c2.execute(
                    f"SELECT COUNT(*) FROM `{tablo_adi}` "
                    f"WHERE `{sutun}` NOT REGEXP %s "
                    f"AND `{sutun}` IS NOT NULL AND TRIM(`{sutun}`)!=''",
                    (deger,))
                ihlal = c2.fetchone()[0]

            elif tip == 'benzersiz':
                c2.execute(
                    f"SELECT COUNT(*) - COUNT(DISTINCT `{sutun}`) "
                    f"FROM `{tablo_adi}`")
                ihlal = c2.fetchone()[0]

            elif tip == 'deger_listesi' and deger:
                izinliler = [v.strip() for v in deger.split(',')]
                fmt = ','.join(['%s'] * len(izinliler))
                c2.execute(
                    f"SELECT COUNT(*) FROM `{tablo_adi}` "
                    f"WHERE `{sutun}` NOT IN ({fmt}) "
                    f"AND `{sutun}` IS NOT NULL AND TRIM(`{sutun}`)!=''",
                    tuple(izinliler))
                ihlal = c2.fetchone()[0]

            c2.close()

            sonuc = {
                'kural_id'  : k['KuralID'],
                'sutun'     : sutun,
                'tip'       : tip,
                'seviye'    : seviye,
                'ihlal_sayisi': ihlal,
                'gecti'     : ihlal == 0
            }
            sonuclar.append(sonuc)

            if ihlal > 0:
                if seviye == 'hata':
                    hata_sayisi += 1
                else:
                    uyari_sayisi += 1

        except Exception as e:
            sonuclar.append({
                'kural_id'    : k['KuralID'],
                'sutun'       : sutun,
                'tip'         : tip,
                'seviye'      : seviye,
                'ihlal_sayisi': -1,
                'gecti'       : False,
                'hata'        : str(e)
            })
            if seviye == 'hata':
                hata_sayisi += 1

    return {
        'gecti'       : hata_sayisi == 0,
        'sonuclar'    : sonuclar,
        'hata_sayisi' : hata_sayisi,
        'uyari_sayisi': uyari_sayisi
    }


def dosya_db_aktar(dosya_id):
    """
    Onaylanmış Excel dosyasını hedef tabloya aktarır.
    Akış: BeforeSP → Excel yükle → Kalite kontrol → AfterSP → Bildirim

    Döner: {'ok': bool, 'msg': str}
    """
    import json as _json
    from datetime import datetime

    conn = None
    try:
        dosya = query("SELECT * FROM excel_dosya WHERE DosyaID=%s", (dosya_id,), fetchone=True)
        if not dosya:
            return {'ok': False, 'msg': 'Dosya kaydı bulunamadı.'}

        if dosya['Durum'] not in ('onaylandi',):
            return {'ok': False, 'msg': f'Aktarım için uygun durum değil: {dosya["Durum"]}'}

        tablo_adi = dosya['HedefTablo']
        dosya_yol = dosya['DosyaYolu']

        if not os.path.exists(dosya_yol):
            execute(
                "UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s",
                (dosya_id,))
            return {'ok': False, 'msg': f'Fiziksel dosya bulunamadı: {dosya_yol}'}

        # Konfigürasyon
        konfig    = query("SELECT * FROM tablo_konfig WHERE TabloAdi=%s", (tablo_adi,), fetchone=True)
        before_sp = sanitize(konfig['BeforeSP']) if konfig and konfig.get('BeforeSP') else None
        after_sp  = sanitize(konfig['AfterSP'])  if konfig and konfig.get('AfterSP')  else None
        mod       = (konfig['YukleModu'] if konfig and konfig.get('YukleModu') else 'truncate')

        # Yükleniyor durumuna al
        execute("UPDATE excel_dosya SET Durum='yukleniyor' WHERE DosyaID=%s", (dosya_id,))

        conn = get_conn()
        if not conn:
            execute("UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s", (dosya_id,))
            return {'ok': False, 'msg': 'Veritabanı bağlantısı kurulamadı.'}

        # ── BeforeSP ────────────────────────────────────────────────────────
        if before_sp:
            try:
                _sp_calistir(conn, before_sp)
                logger.info(f'BeforeSP çalıştı: {before_sp} (DosyaID:{dosya_id})')
            except Exception as e:
                execute("UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s", (dosya_id,))
                conn.close()
                return {'ok': False, 'msg': f'BeforeSP hatası ({before_sp}): {e}'}

        # ── Excel → MySQL ────────────────────────────────────────────────────
        try:
            df = pd.read_excel(dosya_yol, header=0, dtype=str).fillna('')
        except Exception as e:
            execute("UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s", (dosya_id,))
            conn.close()
            return {'ok': False, 'msg': f'Excel okunamadı: {e}'}

        if df.empty:
            execute("UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s", (dosya_id,))
            conn.close()
            return {'ok': False, 'msg': 'Excel dosyası boş.'}

        cur_meta = conn.cursor(dictionary=True)
        cur_meta.execute(f"SHOW COLUMNS FROM `{tablo_adi}`")
        db_cols = [r['Field'] for r in cur_meta.fetchall()]
        cur_meta.close()

        # ETL_DATE sütunu ekle (yoksa)
        if 'ETL_DATE' not in db_cols:
            c = conn.cursor()
            c.execute(f"ALTER TABLE `{tablo_adi}` ADD COLUMN `ETL_DATE` NVARCHAR(30)")
            conn.commit()
            c.close()
            db_cols.append('ETL_DATE')

        db_cols_lower = {c.lower(): c for c in db_cols}
        matched_pairs = []
        for ec in df.columns:
            if ec in db_cols and ec != 'ETL_DATE':
                matched_pairs.append((ec, ec))
            elif ec.lower() in db_cols_lower and db_cols_lower[ec.lower()] != 'ETL_DATE':
                matched_pairs.append((ec, db_cols_lower[ec.lower()]))

        if not matched_pairs:
            execute("UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s", (dosya_id,))
            conn.close()
            return {'ok': False, 'msg': 'Excel sütunları tablo sütunlarıyla eşleşmedi.'}

        matched    = [dc for _, dc in matched_pairs]
        etl_date   = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        all_cols   = matched + ['ETL_DATE']
        col_list   = ', '.join([f'`{c}`' for c in all_cols])
        ph         = ', '.join(['%s'] * len(all_cols))
        ins_sql    = f"INSERT INTO `{tablo_adi}` ({col_list}) VALUES ({ph})"

        eklenen = atlanan = tekrar = 0
        cur_dml = conn.cursor()

        if mod == 'truncate':
            cur_dml.execute(f"TRUNCATE TABLE `{tablo_adi}`")
            conn.commit()
            for _, row in df.iterrows():
                try:
                    vals = [str(row[ec]) for ec, _ in matched_pairs] + [etl_date]
                    cur_dml.execute(ins_sql, vals)
                    eklenen += 1
                except Exception:
                    atlanan += 1
        else:
            col_sel = ', '.join([f'`{c}`' for c in matched])
            cur_dml.execute(f"SELECT {col_sel} FROM `{tablo_adi}`")
            mevcut = set()
            while True:
                batch = cur_dml.fetchmany(5000)
                if not batch:
                    break
                for er in batch:
                    mevcut.add(tuple(str(v) for v in er))
            for _, row in df.iterrows():
                try:
                    vals  = [str(row[ec]) for ec, _ in matched_pairs]
                    tup   = tuple(vals)
                    if tup in mevcut:
                        tekrar += 1
                        continue
                    cur_dml.execute(ins_sql, vals + [etl_date])
                    mevcut.add(tup)
                    eklenen += 1
                except Exception:
                    atlanan += 1

        _tablo_log_kaydet(cur_dml, tablo_adi, dosya['YukleyenID'], 'DOSYA_YUKLE', eklenen, atlanan, tekrar)
        conn.commit()
        cur_dml.close()

        # ── Kalite Kontrol ───────────────────────────────────────────────────
        kalite_sonuc = _kalite_kontrol_calistir(conn, tablo_adi)
        kalite_json  = _json.dumps(kalite_sonuc['sonuclar'], ensure_ascii=False)

        # yukle_log kaydı
        try:
            c = conn.cursor()
            c.execute("""
                INSERT INTO yukle_log
                    (DosyaID, TabloAdi, Durum, Mesaj, EklenenSatir, AtlananSatir, KalisonucJSON)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                dosya_id, tablo_adi,
                'basarili' if kalite_sonuc['gecti'] else 'uyari',
                f"Eklenen:{eklenen} Atlanan:{atlanan} Tekrar:{tekrar} "
                f"KaliteHata:{kalite_sonuc['hata_sayisi']} KaliteUyari:{kalite_sonuc['uyari_sayisi']}",
                eklenen, atlanan, kalite_json
            ))
            conn.commit()
            c.close()
        except Exception as e:
            logger.warning(f'yukle_log yazılamadı (tablo olmayabilir): {e}')

        # Kalite hatası varsa aktarımı geri al
        if not kalite_sonuc['gecti']:
            conn.close()
            execute("UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s", (dosya_id,))
            bildirim_gonder(
                dosya['YukleyenID'], 'yukleme_hatasi',
                f'Kalite Hatası: {dosya["OrijinalAd"]}',
                f'{kalite_sonuc["hata_sayisi"]} kalite kuralı ihlali tespit edildi. '
                f'Veri aktarılmadı.',
                dosya_id
            )
            audit('DOSYA_KALITE_HATASI',
                  f'DosyaID:{dosya_id} Tablo:{tablo_adi} '
                  f'Hata:{kalite_sonuc["hata_sayisi"]} Uyari:{kalite_sonuc["uyari_sayisi"]}')
            return {
                'ok'    : False,
                'msg'   : f'Kalite kontrolü başarısız: {kalite_sonuc["hata_sayisi"]} hata.',
                'kalite': kalite_sonuc
            }

        # ── AfterSP ─────────────────────────────────────────────────────────
        if after_sp:
            try:
                _sp_calistir(conn, after_sp)
                logger.info(f'AfterSP çalıştı: {after_sp} (DosyaID:{dosya_id})')
            except Exception as e:
                logger.error(f'AfterSP hatası ({after_sp}): {e}')
                # AfterSP hatası veriyi geri almaz, sadece loglanır

        conn.close()

        # ── Başarı ──────────────────────────────────────────────────────────
        execute("UPDATE excel_dosya SET Durum='yuklendi' WHERE DosyaID=%s", (dosya_id,))

        mesaj = f'{eklenen} satır aktarıldı.'
        if tekrar:   mesaj += f' {tekrar} tekrar atlandı.'
        if atlanan:  mesaj += f' {atlanan} hatalı atlandı.'
        if kalite_sonuc['uyari_sayisi']:
            mesaj += f' {kalite_sonuc["uyari_sayisi"]} kalite uyarısı.'

        bildirim_gonder(
            dosya['YukleyenID'], 'yuklendi',
            f'Veriler Aktarıldı: {dosya["OrijinalAd"]}',
            mesaj, dosya_id
        )
        audit('DOSYA_DB_AKTARIM',
              f'DosyaID:{dosya_id} Tablo:{tablo_adi} Eklenen:{eklenen} '
              f'Mod:{mod} BeforeSP:{before_sp} AfterSP:{after_sp}')

        return {'ok': True, 'msg': mesaj, 'kalite': kalite_sonuc}

    except Exception as e:
        logger.error(f'dosya_db_aktar hatası DosyaID:{dosya_id}: {e}')
        try:
            execute(
                "UPDATE excel_dosya SET Durum='yukleme_hatasi' WHERE DosyaID=%s",
                (dosya_id,))
        except Exception:
            pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass
        return {'ok': False, 'msg': str(e)}


# ── Sayfa ──

@app.route('/dizin-yonetimi')
@login_gerekli
@yetki_gerekli('Y000007')
def dizin_yonetimi():
    return render_template('dizin_yonetimi.html')

# ── API: Dizin listesi ──

@app.route('/api/dizinler')
@api_login_gerekli
def api_dizinler():
    try:
        dizinler = query("""
            SELECT d.DizinID, d.DizinAdi, d.UstDizinID, d.Aciklama,
                   d.OlusturmaTarihi, k.KullaniciAdi AS OlusturanAdi,
                   u.DizinAdi AS UstDizinAdi
            FROM dizin d
            LEFT JOIN kullanici k ON d.OlusturanID = k.KullaniciID
            LEFT JOIN dizin u ON d.UstDizinID = u.DizinID
            ORDER BY d.UstDizinID IS NOT NULL, d.DizinAdi
        """)
        return jsonify({'ok': True, 'dizinler': dizinler})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Tek dizin detayı (yetkiler + onaylayanlar) ──

@app.route('/api/dizinler/<dizin_id>')
@api_login_gerekli
@api_yetki_gerekli('Y000007')
def api_dizin_detay(dizin_id):
    try:
        dizin = query("SELECT * FROM dizin WHERE DizinID=%s", (dizin_id,), fetchone=True)
        if not dizin:
            return jsonify({'ok': False, 'msg': 'Dizin bulunamadı.'})

        yetkiler = query("""
            SELECT dy.YetkiID, dy.RolID, dy.KullaniciID, dy.YetkiTipi,
                   r.RolAdi, k.KullaniciAdi
            FROM dizin_yetki dy
            LEFT JOIN rol r ON dy.RolID = r.RolID
            LEFT JOIN kullanici k ON dy.KullaniciID = k.KullaniciID
            WHERE dy.DizinID=%s
        """, (dizin_id,))

        onaylayanlar = query("""
            SELECT do.ID, do.OnaylayanID, do.OnayTipi, k.KullaniciAdi
            FROM dizin_onaylayan do
            JOIN kullanici k ON do.OnaylayanID = k.KullaniciID
            WHERE do.DizinID=%s
        """, (dizin_id,))

        return jsonify({'ok': True, 'dizin': dizin, 'yetkiler': yetkiler, 'onaylayanlar': onaylayanlar})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizin ekle ──

@app.route('/api/dizinler', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_ekle():
    try:
        d = request.get_json(force=True)
        adi = d.get('DizinAdi', '').strip()
        if not adi:
            return jsonify({'ok': False, 'msg': 'Dizin adı boş olamaz.'})
        ust = d.get('UstDizinID') or None
        if ust:
            # Maksimum 2 seviye kontrolü
            ust_row = query("SELECT UstDizinID FROM dizin WHERE DizinID=%s", (ust,), fetchone=True)
            if ust_row and ust_row['UstDizinID']:
                return jsonify({'ok': False, 'msg': 'Maksimum 2 seviye dizin destekleniyor.'})
        yeni_id = dizin_id_uret()
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO dizin (DizinID, DizinAdi, UstDizinID, Aciklama, OlusturanID)
            VALUES (%s, %s, %s, %s, %s)
        """, (yeni_id, adi, ust, d.get('Aciklama',''), session.get('kullanici_id')))
        conn.commit()
        conn.close()
        audit('DIZIN_OLUSTUR', f'DizinID: {yeni_id} - {adi}')
        return jsonify({'ok': True, 'DizinID': yeni_id})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizin güncelle ──

@app.route('/api/dizinler/<dizin_id>', methods=['PUT'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_guncelle(dizin_id):
    try:
        d = request.get_json(force=True)
        adi = d.get('DizinAdi', '').strip()
        if not adi:
            return jsonify({'ok': False, 'msg': 'Dizin adı boş olamaz.'})
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("""
            UPDATE dizin SET DizinAdi=%s, Aciklama=%s WHERE DizinID=%s
        """, (adi, d.get('Aciklama',''), dizin_id))
        conn.commit()
        conn.close()
        audit('DIZIN_GUNCELLE', f'DizinID: {dizin_id}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizin sil ──

@app.route('/api/dizinler/<dizin_id>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_sil(dizin_id):
    try:
        # Alt dizin varsa silme
        alt = query("SELECT COUNT(*) AS cnt FROM dizin WHERE UstDizinID=%s", (dizin_id,), fetchone=True)
        if alt and alt['cnt'] > 0:
            return jsonify({'ok': False, 'msg': 'Alt dizinleri önce silin.'})
        # Dosya varsa silme
        dosya = query("SELECT COUNT(*) AS cnt FROM excel_dosya WHERE DizinID=%s", (dizin_id,), fetchone=True)
        if dosya and dosya['cnt'] > 0:
            return jsonify({'ok': False, 'msg': 'Dizin içinde dosya var, önce dosyaları taşıyın veya silin.'})
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("DELETE FROM dizin WHERE DizinID=%s", (dizin_id,))
        conn.commit()
        conn.close()
        audit('DIZIN_SIL', f'DizinID: {dizin_id}')
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizine yetki ekle ──

@app.route('/api/dizinler/<dizin_id>/yetkiler', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_yetki_ekle(dizin_id):
    try:
        d = request.get_json(force=True)
        rol_id  = d.get('RolID')  or None
        kul_id  = d.get('KullaniciID') or None
        tip     = d.get('YetkiTipi', 'okuma')
        if not rol_id and not kul_id:
            return jsonify({'ok': False, 'msg': 'Rol veya kullanıcı seçin.'})
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO dizin_yetki (DizinID, RolID, KullaniciID, YetkiTipi)
            VALUES (%s, %s, %s, %s)
        """, (dizin_id, rol_id, kul_id, tip))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizinden yetki kaldır ──

@app.route('/api/dizin-yetki/<int:yetki_id>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_yetki_sil(yetki_id):
    try:
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("DELETE FROM dizin_yetki WHERE YetkiID=%s", (yetki_id,))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizine onaylayan ekle ──

@app.route('/api/dizinler/<dizin_id>/onaylayanlar', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_onaylayan_ekle(dizin_id):
    try:
        d = request.get_json(force=True)
        onaylayan = d.get('OnaylayanID')
        tip = d.get('OnayTipi', 'dizin')
        if not onaylayan:
            return jsonify({'ok': False, 'msg': 'Onaylayan seçin.'})
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO dizin_onaylayan (DizinID, OnaylayanID, OnayTipi)
            VALUES (%s, %s, %s)
        """, (dizin_id, onaylayan, tip))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Dizinden onaylayan kaldır ──

@app.route('/api/dizin-onaylayan/<int:id>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000007')
@csrf_protect
def api_dizin_onaylayan_sil(id):
    try:
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("DELETE FROM dizin_onaylayan WHERE ID=%s", (id,))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ── API: Bildirimler ──

@app.route('/api/bildirimler')
@api_login_gerekli
def api_bildirimler():
    try:
        rows = query("""
            SELECT BildirimID, Tip, Baslik, Mesaj, DosyaID, Okundu, Tarih
            FROM bildirim WHERE AliciID=%s
            ORDER BY Tarih DESC LIMIT 50
        """, (session.get('kullanici_id'),))
        okunmamis = sum(1 for r in rows if not r['Okundu'])
        return jsonify({'ok': True, 'bildirimler': rows, 'okunmamis': okunmamis})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

@app.route('/api/bildirimler/okundu', methods=['POST'])
@api_login_gerekli
@csrf_protect
def api_bildirim_okundu():
    try:
        conn = get_conn()
        if not conn:
            return jsonify({'ok': False, 'msg': 'DB bağlantısı kurulamadı.'})
        cur = conn.cursor()
        cur.execute("UPDATE bildirim SET Okundu=1 WHERE AliciID=%s", (session.get('kullanici_id'),))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

# ═══════════════════════════════════════════════════════════════════════════════
# MODÜL 2 — DOSYA YÜKLEME + ARŞİV + ONAY AKIŞI
# ═══════════════════════════════════════════════════════════════════════════════

EXCEL_STORE = os.environ.get('EXCEL_STORE_PATH', 'excel_store')
os.makedirs(EXCEL_STORE, exist_ok=True)


def admin_mi(kullanici_id):
    row = query("SELECT RolID FROM kullanici WHERE KullaniciID=%s", (kullanici_id,), fetchone=True)
    return row and row['RolID'] == 'R000001'


def dosya_onay_gerekli_mi(hedef_tablo):
    if not hedef_tablo:
        return True
    row = query("SELECT OnayGerekli FROM tablo_konfig WHERE TabloAdi=%s", (hedef_tablo,), fetchone=True)
    return row['OnayGerekli'] if row else True


def dizin_onaylayanlarini_getir(dizin_id):
    return query("""
        SELECT do.OnaylayanID FROM dizin_onaylayan do WHERE do.DizinID=%s
    """, (dizin_id,))


# ─── Sayfa: /dosya-yukle ─────────────────────────────────────────────────────

@app.route('/dosya-yukle')
@login_gerekli
@yetki_gerekli('Y000008')
def dosya_yukle_page():
    return render_template('dosya_yukle.html')


# ─── Sayfa: /dosya-arsiv ─────────────────────────────────────────────────────

@app.route('/dosya-arsiv')
@login_gerekli
@yetki_gerekli('Y000008')
def dosya_arsiv_page():
    return render_template('dosya_arsiv.html')


# ─── Sayfa: /onay-bekleyenler ────────────────────────────────────────────────

@app.route('/onay-bekleyenler')
@login_gerekli
@yetki_gerekli('Y000009')
def onay_bekleyenler_page():
    return render_template('onay_bekleyenler.html')


# ─── API: Kullanıcının erişebildiği dizinleri getir ──────────────────────────

@app.route('/api/benim-dizinlerim')
@api_login_gerekli
def api_benim_dizinlerim():
    try:
        kid  = session.get('kullanici_id')
        rid  = session.get('rol_id')
        if admin_mi(kid):
            dizinler = query("""
                SELECT d.DizinID, d.DizinAdi, d.UstDizinID, d.Aciklama,
                       u.DizinAdi AS UstDizinAdi
                FROM dizin d LEFT JOIN dizin u ON u.DizinID = d.UstDizinID
                ORDER BY d.UstDizinID IS NULL DESC, d.DizinAdi
            """)
        else:
            izinli = kullanici_dizinleri(kid, rid, sadece_yazma=True)
            if not izinli:
                return jsonify({'ok': True, 'dizinler': []})
            fmt    = ','.join(['%s'] * len(izinli))
            dizinler = query(f"""
                SELECT d.DizinID, d.DizinAdi, d.UstDizinID, d.Aciklama,
                       u.DizinAdi AS UstDizinAdi
                FROM dizin d LEFT JOIN dizin u ON u.DizinID = d.UstDizinID
                WHERE d.DizinID IN ({fmt})
                ORDER BY d.UstDizinID IS NULL DESC, d.DizinAdi
            """, tuple(izinli))
        return jsonify({'ok': True, 'dizinler': dizinler})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Dosya yükle (önizleme + kayıt) ─────────────────────────────────────

@app.route('/api/dosya-yukle', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000008')
@csrf_protect
def api_dosya_yukle():
    try:
        kid     = session.get('kullanici_id')
        rid     = session.get('rol_id')
        dizin_id = request.form.get('dizin_id', '').strip()
        notlar   = request.form.get('notlar', '').strip() or None
        file     = request.files.get('file')

        if not dizin_id:
            return jsonify({'ok': False, 'msg': 'Dizin seçilmedi.'})
        if not file:
            return jsonify({'ok': False, 'msg': 'Dosya seçilmedi.'})

        # Yetki kontrolü
        if not admin_mi(kid):
            izinli = kullanici_dizinleri(kid, rid, sadece_yazma=True)
            if dizin_id not in izinli:
                return jsonify({'ok': False, 'msg': 'Bu dizine yükleme yetkiniz yok.'})

        guvenli_ad = guvenli_dosya_adi(file.filename)
        if not guvenli_ad:
            return jsonify({'ok': False, 'msg': 'Geçersiz dosya uzantısı. (.xlsx, .xls)'})

        # Dosyayı oku
        tmp_path = os.path.join(app.config['UPLOAD_FOLDER'], guvenli_ad)
        file.save(tmp_path)
        try:
            df = pd.read_excel(tmp_path, header=0, dtype=str).fillna('')
        except Exception as e:
            os.remove(tmp_path)
            return jsonify({'ok': False, 'msg': f'Excel okunamadı: {e}'})

        satir_sayisi = len(df)
        kolonlar     = [c for c in df.columns.tolist() if c and not str(c).startswith('Unnamed')]

        # Hash hesapla
        import hashlib
        with open(tmp_path, 'rb') as f:
            dosya_hash = hashlib.sha256(f.read()).hexdigest()

        dosya_boyutu = os.path.getsize(tmp_path)

        # Kalıcı yola taşı
        dosya_id   = str(uuid.uuid4())
        kalici_adi = f"{dosya_id}_{secure_filename(file.filename)}"
        kalici_yol = os.path.join(EXCEL_STORE, kalici_adi)
        os.rename(tmp_path, kalici_yol)

        # Hedef tablo konfigürasyonu
        hedef_tablo = sanitize(os.path.splitext(secure_filename(file.filename))[0])
        konfig = query("SELECT * FROM tablo_konfig WHERE TabloAdi=%s", (hedef_tablo,), fetchone=True)
        onay_gerekli = True if not admin_mi(kid) else (konfig['OnayGerekli'] if konfig else False)

        durum = 'bekliyor' if onay_gerekli else 'onaylandi'

        execute("""
            INSERT INTO excel_dosya
                (DosyaID, DizinID, DosyaAdi, OrijinalAd, HedefTablo, Durum,
                 YukleyenID, DosyaYolu, DosyaHash, DosyaBoyutu, SatirSayisi, Notlar)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (dosya_id, dizin_id, kalici_adi, file.filename, hedef_tablo,
              durum, kid, kalici_yol, dosya_hash, dosya_boyutu, satir_sayisi, notlar))

        audit('DOSYA_YUKLE', f'DosyaID:{dosya_id} Dizin:{dizin_id} Satır:{satir_sayisi}')

        # Admin değilse onaylayanlara bildirim gönder
        if onay_gerekli:
            onaylayanlar = dizin_onaylayanlarini_getir(dizin_id)
            for o in onaylayanlar:
                bildirim_gonder(o['OnaylayanID'], 'onay_bekliyor',
                    f'Onay Bekleyen Dosya: {file.filename}',
                    f'{session.get("kullanici_adi")} tarafından yüklendi.',
                    dosya_id)

        # Onay gerekmiyorsa DB aktarımını arka planda başlat
        if not onay_gerekli:
            threading.Thread(
                target=dosya_db_aktar,
                args=(dosya_id,),
                daemon=True
            ).start()

        return jsonify({
            'ok': True,
            'dosya_id': dosya_id,
            'durum': durum,
            'satir_sayisi': satir_sayisi,
            'kolonlar': kolonlar,
            'onay_gerekli': onay_gerekli,
            'msg': 'Dosya yüklendi, onay bekleniyor.' if onay_gerekli else 'Dosya yüklendi, DB\'ye aktarılıyor…'
        })
    except Exception as e:
        logger.error(f'Dosya yükleme hatası: {e}')
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Arşiv listesi ──────────────────────────────────────────────────────

@app.route('/api/dosya-arsiv')
@api_login_gerekli
@api_yetki_gerekli('Y000008')
def api_dosya_arsiv():
    try:
        kid  = session.get('kullanici_id')
        rid  = session.get('rol_id')
        dizin_filtre = request.args.get('dizin_id')
        durum_filtre = request.args.get('durum')

        if admin_mi(kid):
            where = "1=1"
            params = []
        else:
            izinli = kullanici_dizinleri(kid, rid)
            # Dosya bazlı özel kısıtlama
            if not izinli:
                return jsonify({'ok': True, 'dosyalar': []})
            fmt   = ','.join(['%s'] * len(izinli))
            where = f"""(
                ed.DizinID IN ({fmt})
                AND (
                    NOT EXISTS (SELECT 1 FROM dosya_yetki dy WHERE dy.DosyaID = ed.DosyaID)
                    OR EXISTS (SELECT 1 FROM dosya_yetki dy WHERE dy.DosyaID = ed.DosyaID AND dy.KullaniciID = %s)
                    OR ed.YukleyenID = %s
                )
            )"""
            params = list(izinli) + [kid, kid]

        if dizin_filtre:
            where += " AND ed.DizinID = %s"
            params.append(dizin_filtre)
        if durum_filtre:
            where += " AND ed.Durum = %s"
            params.append(durum_filtre)

        dosyalar = query(f"""
            SELECT ed.DosyaID, ed.DizinID, d.DizinAdi, ed.OrijinalAd, ed.HedefTablo,
                   ed.Durum, ed.YukleyenID, k.KullaniciAdi AS YukleyenAdi,
                   ed.YuklemeTarihi, ed.SatirSayisi, ed.DosyaBoyutu, ed.Notlar,
                   ed.OncekiDosyaID
            FROM excel_dosya ed
            JOIN dizin d     ON d.DizinID      = ed.DizinID
            JOIN kullanici k ON k.KullaniciID  = ed.YukleyenID
            WHERE {where}
            ORDER BY ed.YuklemeTarihi DESC
            LIMIT 200
        """, tuple(params))

        return jsonify({'ok': True, 'dosyalar': dosyalar})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Onay bekleyenler ───────────────────────────────────────────────────

@app.route('/api/onay-bekleyenler')
@api_login_gerekli
@api_yetki_gerekli('Y000009')
def api_onay_bekleyenler():
    try:
        kid = session.get('kullanici_id')
        if admin_mi(kid):
            dosyalar = query("""
                SELECT ed.DosyaID, ed.DizinID, d.DizinAdi, ed.OrijinalAd,
                       ed.HedefTablo, ed.YukleyenID, k.KullaniciAdi AS YukleyenAdi,
                       ed.YuklemeTarihi, ed.SatirSayisi, ed.Notlar
                FROM excel_dosya ed
                JOIN dizin d     ON d.DizinID     = ed.DizinID
                JOIN kullanici k ON k.KullaniciID = ed.YukleyenID
                WHERE ed.Durum = 'bekliyor'
                ORDER BY ed.YuklemeTarihi ASC
            """)
        else:
            dosyalar = query("""
                SELECT ed.DosyaID, ed.DizinID, d.DizinAdi, ed.OrijinalAd,
                       ed.HedefTablo, ed.YukleyenID, k.KullaniciAdi AS YukleyenAdi,
                       ed.YuklemeTarihi, ed.SatirSayisi, ed.Notlar
                FROM excel_dosya ed
                JOIN dizin d            ON d.DizinID      = ed.DizinID
                JOIN kullanici k        ON k.KullaniciID  = ed.YukleyenID
                JOIN dizin_onaylayan do ON do.DizinID     = ed.DizinID
                WHERE ed.Durum = 'bekliyor' AND do.OnaylayanID = %s
                ORDER BY ed.YuklemeTarihi ASC
            """, (kid,))
        return jsonify({'ok': True, 'dosyalar': dosyalar})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Dosya onayla / reddet ──────────────────────────────────────────────

@app.route('/api/dosya-karar/<dosya_id>', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000009')
@csrf_protect
def api_dosya_karar(dosya_id):
    try:
        kid   = session.get('kullanici_id')
        d     = request.get_json(force=True)
        karar = d.get('karar')        # 'onaylandi' veya 'reddedildi'
        acik  = (d.get('aciklama') or '').strip()

        if karar not in ('onaylandi', 'reddedildi'):
            return jsonify({'ok': False, 'msg': 'Geçersiz karar.'})
        if karar == 'reddedildi' and not acik:
            return jsonify({'ok': False, 'msg': 'Red için açıklama zorunludur.'})

        dosya = query("SELECT * FROM excel_dosya WHERE DosyaID=%s", (dosya_id,), fetchone=True)
        if not dosya:
            return jsonify({'ok': False, 'msg': 'Dosya bulunamadı.'})
        if dosya['Durum'] != 'bekliyor':
            return jsonify({'ok': False, 'msg': 'Bu dosya zaten işlenmiş.'})

        # Yetki kontrolü (admin değilse o dizinin onaylayanı mı?)
        if not admin_mi(kid):
            onayci = query("""
                SELECT 1 FROM dizin_onaylayan
                WHERE DizinID=%s AND OnaylayanID=%s
            """, (dosya['DizinID'], kid), fetchone=True)
            if not onayci:
                return jsonify({'ok': False, 'msg': 'Bu dosyayı onaylama yetkiniz yok.'})

        execute("""
            INSERT INTO excel_onay (DosyaID, OnaylayanID, Karar, Aciklama)
            VALUES (%s, %s, %s, %s)
        """, (dosya_id, kid, karar, acik or None))

        yeni_durum = 'onaylandi' if karar == 'onaylandi' else 'reddedildi'
        execute("UPDATE excel_dosya SET Durum=%s WHERE DosyaID=%s", (yeni_durum, dosya_id))

        # Yükleyiciye bildirim
        if karar == 'onaylandi':
            bildirim_gonder(dosya['YukleyenID'], 'onaylandi',
                f'Dosyanız Onaylandı: {dosya["OrijinalAd"]}',
                f'{session.get("kullanici_adi")} tarafından onaylandı.', dosya_id)
        else:
            bildirim_gonder(dosya['YukleyenID'], 'reddedildi',
                f'Dosyanız Reddedildi: {dosya["OrijinalAd"]}',
                f'Sebep: {acik}', dosya_id)

        audit('DOSYA_KARAR', f'DosyaID:{dosya_id} Karar:{karar}')

        # Onaylandıysa DB aktarımını arka planda başlat
        if karar == 'onaylandi':
            threading.Thread(
                target=dosya_db_aktar,
                args=(dosya_id,),
                daemon=True
            ).start()

        return jsonify({'ok': True, 'msg': 'Karar kaydedildi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Dosya onay geçmişi ─────────────────────────────────────────────────

@app.route('/api/dosya-onay-gecmisi/<dosya_id>')
@api_login_gerekli
def api_dosya_onay_gecmisi(dosya_id):
    try:
        rows = query("""
            SELECT eo.Karar, eo.Aciklama, eo.KararTarihi, k.KullaniciAdi
            FROM excel_onay eo
            JOIN kullanici k ON k.KullaniciID = eo.OnaylayanID
            WHERE eo.DosyaID = %s
            ORDER BY eo.KararTarihi DESC
        """, (dosya_id,))
        return jsonify({'ok': True, 'gecmis': rows})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Dosya aktarım durumu (polling için) ────────────────────────────────

@app.route('/api/dosya-durum/<dosya_id>')
@api_login_gerekli
def api_dosya_durum(dosya_id):
    try:
        dosya = query("""
            SELECT ed.DosyaID, ed.OrijinalAd, ed.HedefTablo, ed.Durum,
                   ed.SatirSayisi, ed.YukleTarihi,
                   yl.EklenenSatir, yl.AtlananSatir, yl.Mesaj AS YukleMesaj,
                   yl.KalisonucJSON, yl.Tarih AS AktarimTarihi
            FROM excel_dosya ed
            LEFT JOIN yukle_log yl ON yl.DosyaID = ed.DosyaID
            WHERE ed.DosyaID = %s
            ORDER BY yl.Tarih DESC
            LIMIT 1
        """, (dosya_id,), fetchone=True)
        if not dosya:
            return jsonify({'ok': False, 'msg': 'Dosya bulunamadı.'})
        return jsonify({'ok': True, 'dosya': dosya})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ═══════════════════════════════════════════════════════════════════════════════
# MODÜL 3 — KALİTE KONTROL + TABLO KONFİGÜRASYONU
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Sayfa: /kalite-kurallari ────────────────────────────────────────────────

@app.route('/kalite-kurallari')
@login_gerekli
@yetki_gerekli('Y000011')
def kalite_kurallari_page():
    return render_template('kalite_kurallari.html')


# ─── Sayfa: /tablo-konfig ────────────────────────────────────────────────────

@app.route('/tablo-konfig')
@login_gerekli
@yetki_gerekli('Y000010')
def tablo_konfig_page():
    return render_template('tablo_konfig.html')


# ─── API: Kalite kuralları CRUD ──────────────────────────────────────────────

@app.route('/api/kalite-kurallari')
@api_login_gerekli
@api_yetki_gerekli('Y000011')
def api_kalite_kurallari():
    try:
        tablo = request.args.get('tablo')
        if tablo:
            rows = query("SELECT * FROM kalite_kural WHERE TabloAdi=%s ORDER BY SutunAdi", (tablo,))
        else:
            rows = query("SELECT * FROM kalite_kural ORDER BY TabloAdi, SutunAdi")
        return jsonify({'ok': True, 'kurallar': rows})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/kalite-kurallari', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000011')
@csrf_protect
def api_kalite_kural_ekle():
    try:
        d = request.get_json(force=True)
        tablo  = sanitize(d.get('TabloAdi', ''))
        sutun  = (d.get('SutunAdi') or '').strip()
        tip    = d.get('KuralTipi', '')
        deger  = (d.get('KuralDeger') or '').strip() or None
        seviye = d.get('HataSeviyesi', 'hata')
        acik   = (d.get('Aciklama') or '').strip() or None

        if not tablo or not sutun or not tip:
            return jsonify({'ok': False, 'msg': 'Tablo, sütun ve kural tipi zorunludur.'})

        execute("""
            INSERT INTO kalite_kural (TabloAdi, SutunAdi, KuralTipi, KuralDeger, HataSeviyesi, Aciklama)
            VALUES (%s,%s,%s,%s,%s,%s)
        """, (tablo, sutun, tip, deger, seviye, acik))
        audit('KALITE_KURAL_EKLE', f'{tablo}.{sutun} → {tip}')
        return jsonify({'ok': True, 'msg': 'Kural eklendi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/kalite-kurallari/<int:kid>', methods=['PUT'])
@api_login_gerekli
@api_yetki_gerekli('Y000011')
@csrf_protect
def api_kalite_kural_guncelle(kid):
    try:
        d = request.get_json(force=True)
        execute("""
            UPDATE kalite_kural SET KuralDeger=%s, HataSeviyesi=%s, Aciklama=%s, AktifMi=%s
            WHERE KuralID=%s
        """, (d.get('KuralDeger'), d.get('HataSeviyesi','hata'),
              d.get('Aciklama'), d.get('AktifMi', True), kid))
        return jsonify({'ok': True, 'msg': 'Kural güncellendi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/kalite-kurallari/<int:kid>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000011')
@csrf_protect
def api_kalite_kural_sil(kid):
    try:
        execute("DELETE FROM kalite_kural WHERE KuralID=%s", (kid,))
        return jsonify({'ok': True, 'msg': 'Kural silindi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── API: Tablo konfigürasyonu CRUD ─────────────────────────────────────────

@app.route('/api/tablo-konfig')
@api_login_gerekli
@api_yetki_gerekli('Y000010')
def api_tablo_konfig_listele():
    try:
        rows = query("SELECT * FROM tablo_konfig ORDER BY TabloAdi")
        return jsonify({'ok': True, 'konfig': rows})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/tablo-konfig', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000010')
@csrf_protect
def api_tablo_konfig_ekle():
    try:
        d = request.get_json(force=True)
        tablo = sanitize(d.get('TabloAdi', ''))
        if not tablo:
            return jsonify({'ok': False, 'msg': 'Tablo adı zorunludur.'})
        execute("""
            INSERT INTO tablo_konfig (TabloAdi, YukleModu, BeforeSP, AfterSP, ArtanAnahtar, OnayGerekli, Aciklama)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
            ON DUPLICATE KEY UPDATE
                YukleModu=%s, BeforeSP=%s, AfterSP=%s, ArtanAnahtar=%s, OnayGerekli=%s, Aciklama=%s
        """, (tablo,
              d.get('YukleModu','truncate'), d.get('BeforeSP') or None,
              d.get('AfterSP') or None, d.get('ArtanAnahtar') or None,
              d.get('OnayGerekli', True), d.get('Aciklama') or None,
              d.get('YukleModu','truncate'), d.get('BeforeSP') or None,
              d.get('AfterSP') or None, d.get('ArtanAnahtar') or None,
              d.get('OnayGerekli', True), d.get('Aciklama') or None))
        audit('TABLO_KONFIG', f'Tablo:{tablo}')
        return jsonify({'ok': True, 'msg': 'Konfigürasyon kaydedildi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/tablo-konfig/<int:kid>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000010')
@csrf_protect
def api_tablo_konfig_sil(kid):
    try:
        execute("DELETE FROM tablo_konfig WHERE KonfigID=%s", (kid,))
        return jsonify({'ok': True, 'msg': 'Konfigürasyon silindi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ═══════════════════════════════════════════════════════════════════════════════
# MODÜL 4 — CRON YÖNETİMİ
# ═══════════════════════════════════════════════════════════════════════════════

import threading
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

scheduler = BackgroundScheduler(timezone='Europe/Istanbul')


def cron_sp_calistir(gorev_id, sp_adi, gorev_adi):
    """Bir cron görevini çalıştırır, sonucu loglar."""
    import time
    baslangic = time.time()
    try:
        execute("UPDATE cron_gorev SET SonDurum='calisiyor', SonCalisma=NOW() WHERE GorevID=%s", (gorev_id,))
        conn = get_conn()
        if not conn:
            raise Exception('Veritabanı bağlantısı kurulamadı.')
        cur = conn.cursor()
        cur.execute(f"CALL {sp_adi}()")
        conn.commit()
        conn.close()
        sure = int((time.time() - baslangic) * 1000)
        execute("UPDATE cron_gorev SET SonDurum='basarili', SonMesaj=%s WHERE GorevID=%s",
                (f'Başarıyla çalıştı ({sure}ms)', gorev_id))
        logger.info(f'Cron görev başarılı: {gorev_adi} ({sure}ms)')
    except Exception as e:
        execute("UPDATE cron_gorev SET SonDurum='hata', SonMesaj=%s WHERE GorevID=%s",
                (str(e)[:500], gorev_id))
        logger.error(f'Cron görev hatası [{gorev_adi}]: {e}')


def scheduler_yukle():
    """DB'deki aktif cron görevlerini scheduler'a yükler."""
    try:
        scheduler.remove_all_jobs()
        conn = get_conn()
        if not conn:
            logger.error('Scheduler: DB bağlantısı kurulamadı.')
            return
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM cron_gorev WHERE Aktif=1")
        gorevler = cur.fetchall()
        conn.close()
        for g in gorevler:
            try:
                scheduler.add_job(
                    cron_sp_calistir,
                    CronTrigger.from_crontab(g['CronIfade'], timezone='Europe/Istanbul'),
                    args=[g['GorevID'], g['SpAdi'], g['GorevAdi']],
                    id=f"cron_{g['GorevID']}",
                    replace_existing=True
                )
                logger.info(f"Cron yüklendi: {g['GorevAdi']} → {g['CronIfade']}")
            except Exception as e:
                logger.error(f"Cron yüklenemedi [{g['GorevAdi']}]: {e}")
    except Exception as e:
        logger.error(f'Scheduler yükleme hatası: {e}')


def _scheduler_baslat():
    """İlk istek geldiğinde scheduler'ı başlatır."""
    try:
        if not scheduler.running:
            scheduler.start()
            logger.info('APScheduler başlatıldı.')
        scheduler_yukle()
    except Exception as e:
        logger.warning(f'Scheduler başlatılamadı: {e}')


@app.before_request
def ilk_istek_scheduler():
    """İlk HTTP isteğinde scheduler'ı başlat (request context var)."""
    global _scheduler_started
    if not _scheduler_started:
        _scheduler_started = True
        threading.Thread(target=_scheduler_baslat, daemon=True).start()


_scheduler_started = False


# ─── Sayfa: /cron-yonetimi ───────────────────────────────────────────────────

@app.route('/cron-yonetimi')
@login_gerekli
@yetki_gerekli('Y000012')
def cron_yonetimi_page():
    return render_template('cron_yonetimi.html')


# ─── API: Cron görevleri CRUD ────────────────────────────────────────────────

@app.route('/api/cron-gorevler')
@api_login_gerekli
@api_yetki_gerekli('Y000012')
def api_cron_gorevler():
    try:
        rows = query("""
            SELECT cg.*, k.KullaniciAdi AS OlusturanAdi
            FROM cron_gorev cg
            LEFT JOIN kullanici k ON k.KullaniciID = cg.OlusturanID
            ORDER BY cg.GorevAdi
        """)
        return jsonify({'ok': True, 'gorevler': rows})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/cron-gorevler', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000012')
@csrf_protect
def api_cron_gorev_ekle():
    try:
        d     = request.get_json(force=True)
        adi   = (d.get('GorevAdi') or '').strip()
        sp    = (d.get('SpAdi') or '').strip()
        cron  = (d.get('CronIfade') or '').strip()
        kid   = session.get('kullanici_id')

        if not adi or not sp or not cron:
            return jsonify({'ok': False, 'msg': 'Görev adı, SP adı ve cron ifadesi zorunludur.'})

        # Cron ifadesi geçerli mi?
        try:
            CronTrigger.from_crontab(cron, timezone='Europe/Istanbul')
        except Exception:
            return jsonify({'ok': False, 'msg': f'Geçersiz cron ifadesi: {cron}'})

        execute("""
            INSERT INTO cron_gorev (GorevAdi, SpAdi, CronIfade, Aktif, OlusturanID)
            VALUES (%s,%s,%s,%s,%s)
        """, (adi, sp, cron, d.get('Aktif', True), kid))

        scheduler_yukle()
        audit('CRON_EKLE', f'{adi} → {sp} ({cron})')
        return jsonify({'ok': True, 'msg': 'Görev eklendi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/cron-gorevler/<int:gid>', methods=['PUT'])
@api_login_gerekli
@api_yetki_gerekli('Y000012')
@csrf_protect
def api_cron_gorev_guncelle(gid):
    try:
        d = request.get_json(force=True)
        cron = (d.get('CronIfade') or '').strip()
        try:
            CronTrigger.from_crontab(cron, timezone='Europe/Istanbul')
        except Exception:
            return jsonify({'ok': False, 'msg': f'Geçersiz cron ifadesi: {cron}'})

        execute("""
            UPDATE cron_gorev SET GorevAdi=%s, SpAdi=%s, CronIfade=%s, Aktif=%s WHERE GorevID=%s
        """, (d.get('GorevAdi'), d.get('SpAdi'), cron, d.get('Aktif', True), gid))
        scheduler_yukle()
        audit('CRON_GUNCELLE', f'GorevID:{gid}')
        return jsonify({'ok': True, 'msg': 'Görev güncellendi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/cron-gorevler/<int:gid>', methods=['DELETE'])
@api_login_gerekli
@api_yetki_gerekli('Y000012')
@csrf_protect
def api_cron_gorev_sil(gid):
    try:
        execute("DELETE FROM cron_gorev WHERE GorevID=%s", (gid,))
        scheduler_yukle()
        audit('CRON_SIL', f'GorevID:{gid}')
        return jsonify({'ok': True, 'msg': 'Görev silindi.'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


@app.route('/api/cron-gorevler/<int:gid>/calistir', methods=['POST'])
@api_login_gerekli
@api_yetki_gerekli('Y000012')
@csrf_protect
def api_cron_hemen_calistir(gid):
    try:
        g = query("SELECT * FROM cron_gorev WHERE GorevID=%s", (gid,), fetchone=True)
        if not g:
            return jsonify({'ok': False, 'msg': 'Görev bulunamadı.'})
        threading.Thread(target=cron_sp_calistir,
                         args=(g['GorevID'], g['SpAdi'], g['GorevAdi'])).start()
        audit('CRON_MANUEL', f'{g["GorevAdi"]} manuel çalıştırıldı.')
        return jsonify({'ok': True, 'msg': f'"{g["GorevAdi"]}" çalıştırılıyor…'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})

